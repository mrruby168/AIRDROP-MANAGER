# AirdropSuite — App 2 Refactor: Build & Test Guide

## 1. Danh sách file đã sửa / thêm mới

| File | Loại | Nội dung thay đổi |
|---|---|---|
| `app2/css/style.css` | Sửa | Toàn bộ hệ thống theme Light/Dark bằng CSS variables, tăng typography, sidebar 340px/radius 16px/hover lift/active state |
| `app2/index.html` | Sửa | Script chống-nháy theme trong `<head>`, nút toggle Light/Dark cạnh Settings, toggle switch trong Settings modal |
| `app2/js/sidebar.js` | Sửa | Xoá render category/chain/type thừa trong card sidebar |
| `app2/js/theme.js` | **Mới** | Module quản lý theme: `initTheme / loadTheme / applyTheme / saveTheme / toggleTheme` |
| `backend/config.py` | Sửa | Thêm `resource_path()` + `get_data_dir()`, tách dữ liệu ghi được ra khỏi bundle |
| `backend/storage.py` | Sửa | Dùng `LOGS_DIR/UPLOADS_DIR/DATA_DIR` từ config thay vì tự tính bằng `__file__`; `backup_database` có try/except |
| `backend/main.py` | Sửa | Bọc try/except quanh `create_all`; `/api/logs` không crash nếu thiếu thư mục logs |
| `launcher.py` | Sửa | `open_app_window()` mở App1/App2/Dashboard ở cửa sổ **maximize** (Chrome/Edge/Brave `--app --start-maximized`, fallback `webbrowser.open`); `PROJECT_ROOT` nhận diện đúng khi đóng gói; `try/finally` đảm bảo tắt Backend sạch |
| `assets/app.ico` | **Mới** | Icon mặc định cho bản build (có thể thay bằng icon riêng của bạn) |
| `build.bat` | **Mới** | Script build PyInstaller ONEDIR hoàn chỉnh |

Không đổi: schema DB, API endpoints, business logic, App 1 (giữ nguyên 100%).

---

## 2. Bug đã phát hiện & sửa trong lúc refactor

1. **Circular CSS variable** — trong lúc bulk-replace hex màu sang biến, 4 dòng
   `--overlay / --shadow-sm / --shadow-md / --shadow-lg` trong `:root` bị chính
   quá trình replace ghi đè thành `var(--overlay)` (tự trỏ vào chính nó) — làm
   toàn bộ overlay modal + shadow bị vô hiệu (invalid value → không hiển thị).
   **Đã phát hiện ở bước review cuối và fix lại giá trị rgba() gốc.**
2. **`background:#fff1e3` bị cắt nhầm** thành `var(--card)1e3` do prefix
   `#fff` trùng với đầu chuỗi `#fff1e3` (màu nền badge "important" trong Check
   News). Đã sửa lại thành `var(--orange-bg)`.
3. **`backup_database()`** dùng `os.path.dirname(__file__)` để tìm
   `database.db` — sai đường dẫn khi build .exe (dữ liệu thật nằm ở
   `%LOCALAPPDATA%`, không phải trong bundle). Đã trỏ lại đúng `DATA_DIR` +
   thêm try/except cho trường hợp file chưa tồn tại.
4. **`LOGS_DIR`/`UPLOADS_DIR`** tính bằng `__file__` bên trong `storage.py` —
   không đáng tin cậy khi các module Python được đóng gói dưới dạng bytecode
   trong PyInstaller. Đã chuyển sang tính tập trung 1 chỗ trong `config.py`.
5. **`PROJECT_ROOT`/`BACKEND_DIR`** trong `launcher.py` chỉ dùng `__file__`,
   không nhận diện chế độ đã đóng gói (`sys.frozen` / `sys._MEIPASS`) — sẽ
   sai đường dẫn khi chạy .exe ONEDIR. Đã sửa thành hàm nhận diện đúng cả
   2 trường hợp.
6. **`api_list_log_files()`** gọi `os.listdir(LOGS_DIR)` không try/except —
   nếu thư mục logs bị xoá khi app đang chạy sẽ crash endpoint. Đã bọc
   try/except, trả về danh sách rỗng thay vì lỗi 500.
7. **Zombie process phòng hờ**: khối tắt Backend trong `launcher.py` trước
   đây nằm ngoài try/finally — nếu `show_launcher_window()` ném lỗi không
   lường trước, Backend có thể không được tắt sạch. Đã bọc try/finally.

---

## 3. CSS Theme — tóm tắt hệ biến (đầy đủ nằm trong `app2/css/style.css`)

```css
:root{
  --bg:#F5F7FB; --card:#FFFFFF; --sidebar:#FFFFFF;
  --border:#E5E7EB; --txt:#111827; --txt2:#6b7280; --txt3:#9aa3b2;
  --surface2:#f3f4f6; --surface3:#fafbfc; --hover-bg:#f9fafb;
  --track-bg:#e5e7eb; --overlay:rgba(16,24,40,.5);
  --scrollbar-thumb:#d1d5db; --scrollbar-thumb-hover:#9ca3af;
  --shadow-sm:rgba(0,0,0,.04); --shadow-md:rgba(0,0,0,.06); --shadow-lg:rgba(0,0,0,.25);
  --fs-title:20px; --fs-sidebar-name:16px; --fs-section:17px;
  --fs-body:15px; --fs-number:26px;
  --fw-title:700; --fw-section:600; --fw-body:500;
  color-scheme: light;
}
[data-theme="dark"]{
  --bg:#0B1220; --card:#111827; --sidebar:#0F172A;
  --border:#1F2937; --txt:#F9FAFB; --txt2:#9CA3AF; --txt3:#6B7280;
  --surface2:#1a2333; --surface3:#0d1420; --hover-bg:#0f172a;
  --track-bg:#1F2937; --overlay:rgba(0,0,0,.65);
  --scrollbar-thumb:#334155; --scrollbar-thumb-hover:#475569;
  --shadow-sm:rgba(0,0,0,.3); --shadow-md:rgba(0,0,0,.4); --shadow-lg:rgba(0,0,0,.6);
  color-scheme: dark;
}
```

Mọi card/sidebar/input/button/modal/scrollbar/tooltip/dropdown trong file
đều đã được quy về các biến trên (không còn hex cứng cho các bề mặt UI),
nên đổi theme là đổi màu đồng bộ toàn bộ giao diện, không cần reload.

---

## 4. Theme Toggle — cách hoạt động

- `index.html` có 1 script nhỏ trong `<head>` chạy **trước** khi CSS áp
  dụng: đọc `localStorage.theme`, nếu chưa có thì dùng
  `window.matchMedia('(prefers-color-scheme: dark)')`, rồi set
  `document.documentElement.dataset.theme` ngay → **không bị nháy màu**.
- `app2/js/theme.js` cung cấp `initTheme / loadTheme / applyTheme /
  saveTheme / toggleTheme`, đồng bộ luôn icon Sun/Moon ở header + checkbox
  trong Settings modal + lắng nghe khi OS đổi theme lúc app đang mở (nếu
  người dùng chưa từng chọn thủ công).
- Nút toggle nằm ngay cạnh nút Settings trong header, gọi `toggleTheme()`.

---

## 5. Desktop Window (launcher.py)

`open_app_window(url, profile_tag)`:
1. Tìm Chrome → Edge → Brave (Windows: Program Files + PATH).
2. Nếu có: mở `--app=<url> --start-maximized --window-size=1280,800
   --user-data-dir=<profile riêng>` → cửa sổ ứng dụng độc lập, maximize
   ngay khi mở, không thanh địa chỉ.
3. Nếu máy không có trình duyệt nào ở trên: fallback
   `webbrowser.open(url)` (mở tab trình duyệt mặc định) — **không bao giờ
   crash chỉ vì thiếu Chrome/Edge**.

Áp dụng cho cả App 1 / App 2 / Backend Dashboard.

---

## 6. resource_path() / get_data_dir() (backend/config.py)

```python
def resource_path(*parts: str) -> str:
    """Đường dẫn tới resource ĐỌC-ONLY (bundle cùng .exe)."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        base = os.path.join(sys._MEIPASS, "backend")
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, *parts)

def get_data_dir() -> str:
    """Đường dẫn GHI ĐƯỢC (database/log/upload), tách khỏi bundle.
    Dev: cạnh backend/. Đã đóng gói: %LOCALAPPDATA%/AirdropSuite."""
    if getattr(sys, "frozen", False):
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        data_dir = os.path.join(base, "AirdropSuite")
    else:
        data_dir = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(data_dir, exist_ok=True)
    return data_dir
```

`launcher.py` có helper tương đương (`_get_project_root()` /
`_get_data_dir()`) dùng cùng logic cho cửa sổ Tkinter + browser profile.

---

## 7. Hướng dẫn build EXE

1. Cài Python 3.10+ (tick "Add to PATH" lúc cài).
2. Mở Command Prompt tại thư mục gốc project (nơi có `launcher.py`).
3. Chạy:
   ```
   build.bat
   ```
4. Script sẽ tự: cài `requirements.txt` + PyInstaller → tạm tách
   `backend/database.db` (dữ liệu dev) ra khỏi bản build → đóng gói
   ONEDIR với icon `assets/app.ico` → khôi phục lại `database.db` cho máy
   dev → báo kết quả.
5. Kết quả nằm ở `dist/AirdropSuite/AirdropSuite.exe`.
6. **Copy cả thư mục `dist/AirdropSuite`** sang máy khác (ONEDIR cần đầy
   đủ file/DLL bên trong `_internal`, không chỉ riêng file `.exe`).

Muốn dùng icon riêng: thay file `assets/app.ico` trước khi chạy `build.bat`.

---

## 8. Checklist test trước khi phát hành

**Giao diện / Theme**
- [ ] Mở app2 lần đầu (chưa từng chọn theme) → theme khớp với theme hệ điều hành.
- [ ] Bấm nút Light/Dark ở header → toàn bộ card/sidebar/input/button/modal/scrollbar đổi màu ngay, không reload.
- [ ] Mở Settings modal → toggle switch Dark Mode phản ánh đúng theme hiện tại; bấm toggle trong modal cũng đổi theme.
- [ ] Tắt app, mở lại → theme đã chọn được giữ nguyên (localStorage).
- [ ] Xoá `localStorage`, đổi theme hệ điều hành → mở lại app2 → theme theo OS.

**Sidebar / Layout**
- [ ] Card "ALL PROJECTS" chỉ còn Tên / ACTIVE / Score / Progress% — không còn TESTNET/DEPIN/category dài dòng.
- [ ] Sidebar rộng 340px ở màn hình ≥1300px, thu gọn hợp lý ở 1366×768 và 1920×1080.
- [ ] Hover vào project card → nâng nhẹ (translateY) + đổ bóng.
- [ ] Project đang chọn có viền xanh + nền xanh mờ, dark mode vẫn rõ ràng.

**Chữ / Typography**
- [ ] Tên project (center panel) ~20px đậm.
- [ ] Tên project trong sidebar ~16px đậm.
- [ ] Số liệu (Sum Value / Stat Value) ~26px.
- [ ] Chữ mô tả (accordion, roadmap, check news) dễ đọc hơn bản cũ.

**Desktop / Build**
- [ ] `python launcher.py` chạy bình thường như trước (không đổi hành vi dev).
- [ ] Bấm "APP 2" trong Control Center → mở cửa sổ maximize (nếu máy có Chrome/Edge/Brave); nếu không có, mở tab trình duyệt mặc định — không crash.
- [ ] Đóng cửa sổ Control Center → Backend tắt hẳn, không còn process `python`/`uvicorn` sót lại (Task Manager).
- [ ] Chạy `build.bat` → build ra `dist/AirdropSuite/AirdropSuite.exe` không lỗi.
- [ ] Copy `dist/AirdropSuite` sang máy Windows khác (không cài Python) → chạy `AirdropSuite.exe` → không mở console đen, không crash.
- [ ] Trên máy khác: xoá `%LOCALAPPDATA%\AirdropSuite` (nếu có từ lần test trước) → chạy lại → app tự tạo `database.db`, `logs/`, `uploads/` mới, không lỗi.
- [ ] Test khi thiếu logo dự án (URL logo hỏng) → hiển thị placeholder chữ cái đầu, không crash.

---

## 9. Ghi chú quan trọng

- **Không đổi** schema DB, API, business logic — chỉ UI/UX + hạ tầng build desktop.
- App 1 giữ nguyên 100%, không chỉnh sửa.
- Dữ liệu người dùng cuối (database.db thật khi dùng bản .exe) nằm ở
  `%LOCALAPPDATA%\AirdropSuite`, tách biệt hoàn toàn khỏi thư mục cài đặt.
