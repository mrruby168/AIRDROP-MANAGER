/**
 * accordion.js
 * Render 8 mục Accordion (Information, Funding, Community, Development,
 * News, Tokenomics, AI Analysis, Notes) bên trong 1 Card "DETAIL" duy nhất.
 * - DETAIL card: mặc định đóng, click để mở/đóng.
 * - Bên trong: chỉ 1 mục Accordion được mở tại 1 thời điểm.
 * - Mỗi mục (trừ News) có thể chuyển sang chế độ "Nhập thủ công" để sửa trực tiếp.
 * (Roadmap & Progress đã tách thành card riêng phía trên Dashboard — xem dashboard-editor.js)
 */

let openAccordionIndex = -1;
let editingAccordionKey = null;

const ACCORDION_DEF = [
  { key: 'info', title: 'Information', iconName: 'info', render: renderInfo, editable: true },
  { key: 'funding', title: 'Funding & Backers', iconName: 'wallet', render: renderFunding, editable: true },
  { key: 'community', title: 'Community', iconName: 'users', render: renderCommunity, editable: true },
  { key: 'development', title: 'Development', iconName: 'code', render: renderDevelopment, editable: true },
  { key: 'news', title: 'News & Updates', iconName: 'newspaper', render: renderNews, editable: false },
  { key: 'tokenomics', title: 'Tokenomics', iconName: 'pieChart', render: renderTokenomics, editable: true },
  { key: 'ai_analysis', title: 'AI Analysis', iconName: 'sparkles', render: renderAIAnalysis, editable: true },
  { key: 'notes', title: 'Notes', iconName: 'fileText', render: renderNotes, editable: true }
];

/** Cấu hình field cho từng mục có thể "Nhập thủ công". */
const EDITABLE_FIELDS = {
  info: [
    { id: 'description', label: 'Mô tả', type: 'textarea', path: 'info.description' },
    { id: 'chain', label: 'Chain', type: 'text', path: 'info.chain' },
    { id: 'type', label: 'Loại dự án', type: 'text', path: 'info.type' }
  ],
  funding: [
    { id: 'total', label: 'Tổng gọi vốn', type: 'text', path: 'funding.total' },
    { id: 'round', label: 'Vòng gọi vốn', type: 'text', path: 'funding.round' },
    { id: 'backers', label: 'Backers (phân cách bằng dấu phẩy)', type: 'text', path: 'backers', isArrayCsv: true }
  ],
  community: [
    { id: 'score', label: 'Điểm Community (0-100)', type: 'number', path: 'community.score' },
    { id: 'followers', label: 'Followers', type: 'text', path: 'community.followers' },
    { id: 'discord', label: 'Discord Members', type: 'text', path: 'community.discord' }
  ],
  development: [
    { id: 'score', label: 'Điểm Development (0-100)', type: 'number', path: 'development.score' },
    { id: 'status', label: 'Trạng thái', type: 'text', path: 'development.status' }
  ],
  tokenomics: [
    { id: 'tge', label: 'TGE', type: 'text', path: 'tokenomics.tge' },
    { id: 'utility', label: 'Utility', type: 'text', path: 'tokenomics.utility' }
  ],
  ai_analysis: [
    { id: 'overall', label: 'Đánh giá tổng quan', type: 'text', path: 'ai_analysis.overall' },
    { id: 'summary', label: 'Tóm tắt', type: 'textarea', path: 'ai_analysis.summary' }
  ],
  notes: [
    { id: 'notes', label: 'Ghi chú', type: 'textarea', path: 'notes' }
  ]
};

function renderAccordion(project) {
  const container = document.getElementById('accordion');
  const analysis = project.analysis || {};

  container.innerHTML = ACCORDION_DEF.map((def, i) => {
    const isOpen = i === openAccordionIndex;
    const isEditing = isOpen && editingAccordionKey === def.key;
    const meta = def.render(analysis, true); // true = preview mode

    let bodyHtml = '';
    if (isOpen) {
      bodyHtml = isEditing ? renderEditForm(def.key, analysis) : def.render(analysis, false);
    }

    return `
      <div class="acc-item ${isOpen ? 'open' : ''}" data-index="${i}">
        <div class="acc-header" onclick="toggleAccordion(${i})">
          <div class="acc-header-left">
            <div class="acc-icon">${icon(def.iconName, 15)}</div>
            <span class="acc-title">${def.title}</span>
            <span class="acc-meta">${meta}</span>
          </div>
          <div class="acc-header-right">
            ${(def.editable && isOpen && !isEditing) ? `
              <button class="acc-edit-btn" onclick="event.stopPropagation(); startEditAccordion('${def.key}')" title="Nhập thủ công">
                ${icon('edit', 13)} Sửa
              </button>` : ''}
            <span class="acc-arrow">${icon('chevronDown', 14)}</span>
          </div>
        </div>
        <div class="acc-body">
          <div class="acc-content">
            ${bodyHtml}
          </div>
        </div>
      </div>`;
  }).join('');
}

function toggleAccordion(index) {
  if (openAccordionIndex === index) {
    openAccordionIndex = -1;
  } else {
    openAccordionIndex = index;
  }
  editingAccordionKey = null;
  const project = sidebarProjects.find(p => p.id === selectedProjectId);
  if (project) renderAccordion(project);
}

function startEditAccordion(key) {
  editingAccordionKey = key;
  const project = sidebarProjects.find(p => p.id === selectedProjectId);
  if (project) renderAccordion(project);
}

function cancelEditAccordion() {
  editingAccordionKey = null;
  const project = sidebarProjects.find(p => p.id === selectedProjectId);
  if (project) renderAccordion(project);
}

/**
 * Dựng form "Nhập thủ công" cho 1 mục, dựa theo EDITABLE_FIELDS[key].
 */
function renderEditForm(key, analysis) {
  const fields = EDITABLE_FIELDS[key] || [];
  const rows = fields.map(f => {
    const raw = safeGet(analysis, f.path, '');
    const value = f.isArrayCsv ? (Array.isArray(raw) ? raw.join(', ') : '') : raw;
    const inputId = `edit-field-${key}-${f.id}`;
    const control = f.type === 'textarea'
      ? `<textarea id="${inputId}" rows="3">${esc(value)}</textarea>`
      : `<input type="${f.type}" id="${inputId}" value="${esc(value)}">`;
    return `<div class="form-row"><label>${esc(f.label)}</label>${control}</div>`;
  }).join('');

  return `
    <div class="acc-edit-form">
      ${rows}
      <div class="acc-edit-actions">
        <button class="btn" onclick="cancelEditAccordion()">Hủy</button>
        <button class="btn btn-primary" onclick="saveAccordionEdit('${key}')">Lưu</button>
      </div>
    </div>`;
}

async function saveAccordionEdit(key) {
  const fields = EDITABLE_FIELDS[key] || [];
  const values = {};
  for (const f of fields) {
    const el = document.getElementById(`edit-field-${key}-${f.id}`);
    if (!el) continue;
    let v = el.value;
    if (f.type === 'number') v = v === '' ? null : Number(v);
    if (f.isArrayCsv) v = v.split(',').map(s => s.trim()).filter(Boolean);
    values[f.path] = v;
  }

  const ok = await patchProjectAnalysis(selectedProjectId, (a) => {
    for (const path in values) setPath(a, path, values[path]);
  }, 'Đã lưu thay đổi');

  if (ok) {
    editingAccordionKey = null;
    renderDashboard(selectedProjectId);
  }
}

/* ------------------------------------------------------------------ */
/* DETAIL CARD — wrapper collapsible bên ngoài toàn bộ Accordion
/* ------------------------------------------------------------------ */
function toggleDetailCard() {
  document.getElementById('detail-card').classList.toggle('open');
}

/** Mở Detail card + mở đúng mục accordion tương ứng với `key`. */
function openDetailSection(key) {
  const idx = ACCORDION_DEF.findIndex(d => d.key === key);
  if (idx === -1) return;
  openAccordionIndex = idx;
  editingAccordionKey = null;
  document.getElementById('detail-card').classList.add('open');
  const project = sidebarProjects.find(p => p.id === selectedProjectId);
  if (project) renderAccordion(project);
  requestAnimationFrame(() => {
    document.getElementById('detail-card').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
}

/* --- Render helpers (chế độ xem / preview) --- */
function renderInfo(a, preview) {
  const chain = safeGet(a, 'info.chain', '');
  const type = safeGet(a, 'info.type', '');
  const parts = [chain, type].filter(Boolean);
  const txt = parts.join(' • ') || '—';
  if (preview) return esc(txt);
  const desc = safeGet(a, 'info.description', 'Chưa có thông tin chi tiết.');
  return `<p>${esc(desc)}</p>
    <div class="kv-row"><span class="kv-key">Chain</span><span class="kv-val">${esc(chain || '—')}</span></div>
    <div class="kv-row"><span class="kv-key">Type</span><span class="kv-val">${esc(type || '—')}</span></div>`;
}

function renderFunding(a, preview) {
  const total = safeGet(a, 'funding.total', '—');
  const round = safeGet(a, 'funding.round', '—');
  const backers = safeGet(a, 'backers', []);
  if (preview) return esc(`${total} • ${round} • ${backers.length} Backers`);
  return `
    <div class="kv-row"><span class="kv-key">Total Raised</span><span class="kv-val">${esc(total)}</span></div>
    <div class="kv-row"><span class="kv-key">Round</span><span class="kv-val">${esc(round)}</span></div>
    <div class="kv-row"><span class="kv-key">Backers</span><span class="kv-val">${backers.length ? backers.map(b => esc(String(b))).join(', ') : '—'}</span></div>`;
}

function renderCommunity(a, preview) {
  const score = safeGet(a, 'community.score', null);
  const followers = safeGet(a, 'community.followers', '—');
  const discord = safeGet(a, 'community.discord', '—');
  if (preview) return esc(`${score !== null ? score + '/100' : '—'} • ${followers} Followers • ${discord} Discord`);
  return `
    <div class="kv-row"><span class="kv-key">Score</span><span class="kv-val">${score !== null ? score + '/100' : '—'}</span></div>
    <div class="kv-row"><span class="kv-key">Followers</span><span class="kv-val">${esc(followers)}</span></div>
    <div class="kv-row"><span class="kv-key">Discord Members</span><span class="kv-val">${esc(discord)}</span></div>`;
}

function renderDevelopment(a, preview) {
  const score = safeGet(a, 'development.score', null);
  const status = safeGet(a, 'development.status', '—');
  if (preview) return esc(`${score !== null ? score + '/100' : '—'} • ${status}`);
  return `
    <div class="kv-row"><span class="kv-key">Score</span><span class="kv-val">${score !== null ? score + '/100' : '—'}</span></div>
    <div class="kv-row"><span class="kv-key">Status</span><span class="kv-val">${esc(status)}</span></div>`;
}

function renderNews(a, preview) {
  const news = safeGet(a, 'news', []);
  const count = news.length;
  if (preview) return esc(`${count} sự kiện`);
  if (!count) return '<p>Chưa có tin tức. Thêm ở mục Important Events phía trên.</p>';
  return '<ul>' + news.map(n => `<li><strong>${esc(n.summary || n.title || '—')}</strong> <span style="color:var(--txt3)">— ${esc(n.date || '')}</span>${n.link ? ` — <a href="${esc(n.link)}" target="_blank" rel="noopener" style="color:var(--green)">Link</a>` : ''}</li>`).join('') + '</ul>';
}

function renderTokenomics(a, preview) {
  const tge = safeGet(a, 'tokenomics.tge', '—');
  const utility = safeGet(a, 'tokenomics.utility', '—');
  if (preview) return esc(`TGE: ${tge} • Utility: ${utility}`);
  return `
    <div class="kv-row"><span class="kv-key">TGE</span><span class="kv-val">${esc(tge)}</span></div>
    <div class="kv-row"><span class="kv-key">Utility</span><span class="kv-val">${esc(utility)}</span></div>`;
}

function renderAIAnalysis(a, preview) {
  const overall = safeGet(a, 'ai_analysis.overall', '—');
  const summary = safeGet(a, 'ai_analysis.summary', '');
  if (preview) return esc(`Overall: ${overall}`);
  return `<p><strong>Overall:</strong> ${esc(overall)}</p><p>${esc(summary || 'Chưa có phân tích AI.')}</p>`;
}

function renderNotes(a, preview) {
  const notes = safeGet(a, 'notes', '');
  if (preview) return esc(notes ? notes.slice(0, 40) + (notes.length > 40 ? '...' : '') : '—');
  return `<p>${esc(notes) || 'Chưa có ghi chú.'}</p>`;
}
