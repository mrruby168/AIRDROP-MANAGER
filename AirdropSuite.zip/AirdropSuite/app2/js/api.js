/**
 * api.js
 * Tầng API duy nhất — tất cả fetch tập trung ở đây.
 */

async function fetchWithTimeout(url, options = {}, timeout = 10000) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  try {
    const res = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(id);
    return res;
  } catch (err) {
    clearTimeout(id);
    throw err;
  }
}

function apiUrl(path) {
  return CONFIG.apiBase.replace(/\/$/, '') + path;
}

async function apiGetProjects() {
  const res = await fetchWithTimeout(apiUrl('/api/projects'));
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function apiGetProject(id) {
  const res = await fetchWithTimeout(apiUrl(`/api/project/${id}`));
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function apiGetStats() {
  const res = await fetchWithTimeout(apiUrl('/api/stats'));
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function apiGetActivity(limit = 20) {
  const res = await fetchWithTimeout(apiUrl(`/api/activity?limit=${limit}`));
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function apiGetExport() {
  const res = await fetchWithTimeout(apiUrl('/api/export'));
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function apiPostImport(projects) {
  const res = await fetchWithTimeout(apiUrl('/api/import'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ projects })
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function apiHealth() {
  try {
    const res = await fetchWithTimeout(apiUrl('/api/health'), {}, 5000);
    return res.ok;
  } catch {
    return false;
  }
}
