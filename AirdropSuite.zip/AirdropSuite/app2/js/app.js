/**
 * app.js
 * Main controller — init, event wiring, refresh, settings, health check, tab routing.
 * Mỗi Tab (Dashboard / Check News / AI Tool) là một workspace độc lập:
 * chỉ container của Tab đang active được hiển thị, không render lẫn nội dung Tab khác.
 */

let isLoading = false;
let currentTab = 'dashboard';

/* ------------------------------------------------------------------ */
/* INIT
/* ------------------------------------------------------------------ */
document.addEventListener('DOMContentLoaded', () => {
  initSearch();
  loadAllData();
  startHealthCheck();
  restoreLastCheckMeta();

  // Escape closes modals
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeSettingsModal();
      closeDetailModal();
    }
  });
});

/* ------------------------------------------------------------------ */
/* DATA LOAD
/* ------------------------------------------------------------------ */
async function loadAllData() {
  if (isLoading) return;
  isLoading = true;
  showSidebarSkeleton();

  try {
    const projects = await apiGetProjects();
    sidebarProjects = Array.isArray(projects) ? projects : [];
    renderSidebar();

    if (sidebarProjects.length) {
      if (!selectedProjectId || !sidebarProjects.find(p => p.id === selectedProjectId)) {
        selectedProjectId = sidebarProjects[0].id;
      }
      renderSidebar(); // re-render để highlight active
      renderDashboard(selectedProjectId);
    } else {
      document.getElementById('center-empty').style.display = 'flex';
      document.getElementById('center-content').style.display = 'none';
    }

    onCheckConfigChange(); // cập nhật lại "Sẽ check N dự án" nếu đang ở tab Check News
    updateBackendStatus(true);
  } catch (err) {
    console.error('[loadAllData]', err);
    updateBackendStatus(false);
    toast('Không tải được dữ liệu từ Backend', 'err');
    document.getElementById('project-list').innerHTML = `
      <div class="center-empty" style="padding:40px 12px">
        <div class="empty-icon-wrap">${icon('alertTriangle', 32)}</div>
        <h3>Connection Error</h3>
        <p style="font-size:12px">${esc(err.message)}</p>
      </div>`;
  } finally {
    isLoading = false;
  }
}

/* ------------------------------------------------------------------ */
/* REFRESH
/* ------------------------------------------------------------------ */
function refreshData() {
  const btn = document.getElementById('btn-refresh');
  btn.style.opacity = '0.6';
  loadAllData().finally(() => { btn.style.opacity = '1'; });
}

/* ------------------------------------------------------------------ */
/* TABS — mỗi tab là 1 view-container riêng biệt, không lồng nội dung nhau
/* ------------------------------------------------------------------ */
const VIEW_IDS = {
  dashboard: 'view-dashboard',
  checknews: 'view-checknews',
  aitool: 'view-aitool'
};

function setTab(tabId) {
  if (!VIEW_IDS[tabId]) return;
  currentTab = tabId;

  document.querySelectorAll('.tab-item').forEach(t => t.classList.toggle('active', t.dataset.tab === tabId));

  Object.entries(VIEW_IDS).forEach(([id, elId]) => {
    document.getElementById(elId).style.display = (id === tabId) ? 'block' : 'none';
  });

  // Search & Filters ở header chỉ có ý nghĩa với Dashboard (project list)
  const searchWrap = document.getElementById('header-search-wrap');
  const filterBtn = document.getElementById('header-filter-btn');
  const showDashboardControls = tabId === 'dashboard';
  searchWrap.classList.toggle('header-hidden', !showDashboardControls);
  filterBtn.classList.toggle('header-hidden', !showDashboardControls);
}

/* ------------------------------------------------------------------ */
/* SETTINGS
/* ------------------------------------------------------------------ */
function openSettingsModal() {
  document.getElementById('settings-modal').style.display = 'flex';
  document.getElementById('setting-api-url').value = CONFIG.apiBase;
  checkHealthForSettings();
}
function closeSettingsModal() {
  document.getElementById('settings-modal').style.display = 'none';
}
function closeSettingsOnBg(e) { if (e.target.id === 'settings-modal') closeSettingsModal(); }

function saveSettings() {
  const url = document.getElementById('setting-api-url').value.trim();
  if (!url) { toast('Vui lòng nhập API URL', 'warn'); return; }
  CONFIG.apiBase = url;
  localStorage.setItem('ap_api_url', url);
  closeSettingsModal();
  toast('Đã lưu cài đặt');
  refreshData();
}

async function checkHealthForSettings() {
  const badge = document.getElementById('settings-health-badge');
  const sub = document.getElementById('settings-health-sub');
  const ok = await apiHealth();
  if (ok) {
    badge.textContent = '🟢 Online';
    badge.style.color = 'var(--green)';
    sub.textContent = 'Backend đang hoạt động bình thường';
  } else {
    badge.textContent = '🔴 Offline';
    badge.style.color = 'var(--red)';
    sub.textContent = 'Không kết nối được Backend';
  }
}

/* ------------------------------------------------------------------ */
/* DETAIL MODAL — dùng chung cho Roadmap "Xem chi tiết" & Check News
/* ------------------------------------------------------------------ */
function openDetailModal(title, bodyHtml) {
  document.getElementById('detail-modal-title').textContent = title;
  document.getElementById('detail-modal-body').innerHTML = bodyHtml;
  document.getElementById('detail-modal').style.display = 'flex';
}
function closeDetailModal() {
  document.getElementById('detail-modal').style.display = 'none';
}
function closeDetailModalOnBg(e) { if (e.target.id === 'detail-modal') closeDetailModal(); }

/* ------------------------------------------------------------------ */
/* HEALTH CHECK
/* ------------------------------------------------------------------ */
function startHealthCheck() {
  checkHealth();
  setInterval(checkHealth, CONFIG.healthInterval);
}

async function checkHealth() {
  const ok = await apiHealth();
  updateBackendStatus(ok);
}

function updateBackendStatus(ok) {
  const dot = document.getElementById('bs-dot');
  const txt = document.getElementById('bs-text');
  if (ok) {
    dot.className = 'bs-dot online';
    txt.textContent = 'Connected';
    txt.style.color = 'var(--green)';
  } else {
    dot.className = 'bs-dot offline';
    txt.textContent = 'Offline';
    txt.style.color = 'var(--red)';
  }
}

/* ------------------------------------------------------------------ */
/* TOAST
/* ------------------------------------------------------------------ */
let toastTimer = null;
function toast(msg, type = 'ok') {
  const el = document.getElementById('toast');
  const dot = document.getElementById('toast-dot');
  dot.className = 'tdot' + (type === 'warn' ? ' warn' : type === 'err' ? ' err' : '');
  document.getElementById('toast-msg').textContent = msg;
  el.className = 'toast show';
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.className = 'toast hide', 3000);
}
