/**
 * checknews.js
 * Tab Check News — độc lập hoàn toàn với Dashboard/AI Tool.
 * Chỉ dùng để: Check tin mới + Xem tin mới (không ghi dữ liệu vào Dashboard).
 * Việc lưu/điền chi tiết dự án được thực hiện riêng ở Dashboard (Prompt AI / Import JSON — xem dashboard-editor.js).
 * Luồng: Chọn cấu hình -> Tạo Prompt -> Dán kết quả AI (JSON) -> Đọc kết quả -> View Source.
 */

let cnResults = [];
let cnFilter = 'all';       // all | critical | important | none
let cnPage = 1;
let cnIdCounter = 0;
const CN_PAGE_SIZE = 6;
const LAST_CHECK_KEY = 'ap_checknews_last';

/* ------------------------------------------------------------------ */
/* CONFIG PANEL
/* ------------------------------------------------------------------ */
function onCheckConfigChange() {
  // Highlight option-card (News/Deep, Only X/Multi Source) theo radio đang chọn
  document.querySelectorAll('.option-card').forEach(card => {
    const input = card.querySelector('input');
    card.classList.toggle('checked', !!input?.checked);
  });

  const testnetChecked = document.getElementById('prompt-cat-testnet')?.checked;
  const depinChecked = document.getElementById('prompt-cat-depin')?.checked;
  const allBox = document.getElementById('prompt-cat-all');
  if (allBox) allBox.checked = !!(testnetChecked && depinChecked);

  const projects = getSelectedCheckProjects();
  const testnetCount = projects.filter(p => p.category === 'TESTNET').length;
  const depinCount = projects.filter(p => p.category === 'DEPIN').length;
  const box = document.getElementById('cn-info-box');
  if (box) box.textContent = `Sẽ check ${projects.length} dự án (Testnet: ${testnetCount}, DePIN: ${depinCount})`;
}

function toggleAllCategories() {
  const all = document.getElementById('prompt-cat-all').checked;
  document.getElementById('prompt-cat-testnet').checked = all;
  document.getElementById('prompt-cat-depin').checked = all;
  onCheckConfigChange();
}

function toggleAdvancedOptions() {
  const body = document.getElementById('cn-advanced-body');
  const btn = document.querySelector('.cn-advanced-toggle');
  const open = body.style.display === 'none';
  body.style.display = open ? 'block' : 'none';
  btn.classList.toggle('open', open);
}

function getSelectedCheckProjects() {
  const testnetChecked = document.getElementById('prompt-cat-testnet')?.checked;
  const depinChecked = document.getElementById('prompt-cat-depin')?.checked;
  const onlyFav = document.getElementById('cn-only-favorite')?.checked;
  return sidebarProjects.filter(p => {
    const catOk = (p.category === 'TESTNET' && testnetChecked) || (p.category === 'DEPIN' && depinChecked);
    if (!catOk) return false;
    if (onlyFav && !p.favorite) return false;
    return true;
  });
}

/* ------------------------------------------------------------------ */
/* PARSE KẾT QUẢ AI (JSON dán vào)
/* ------------------------------------------------------------------ */
function analyzeAiResult() {
  const raw = (document.getElementById('cn-ai-result-input').value || '').trim();
  if (!raw) { toast('Vui lòng dán kết quả JSON từ AI', 'warn'); return; }

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    toast('JSON không hợp lệ: ' + e.message, 'err');
    return;
  }

  const arr = Array.isArray(parsed) ? parsed
    : Array.isArray(parsed?.projects) ? parsed.projects
    : [parsed];

  if (!arr.length) { toast('Không tìm thấy dữ liệu dự án trong JSON', 'warn'); return; }

  cnResults = arr.map(item => buildResultEntry(item));
  cnFilter = 'all';
  cnPage = 1;

  const meta = cnLastPromptMeta || buildCheckConfig();
  const nowIso = new Date().toISOString();
  saveLastCheckMeta(meta, nowIso);

  document.getElementById('cn-updated-at').textContent = new Date(nowIso).toLocaleString('vi-VN');
  document.getElementById('cn-prompt-stage').style.display = 'none';
  document.getElementById('cn-empty-state').style.display = 'none';
  document.getElementById('cn-results-stage').style.display = 'block';

  renderCheckNewsResults();
  toast(`Đã phân tích ${cnResults.length} dự án`);
}

function buildResultEntry(raw) {
  const name = raw.project_name || raw.name || '';
  const matched = matchProject(name);
  const newsListRaw = safeGet(raw, 'analysis.news', []);
  const newsList = Array.isArray(newsListRaw) ? newsListRaw : [];
  return {
    _id: cnIdCounter++,
    name: name || (matched ? matched.name : 'Unknown'),
    category: raw.category || matched?.category || '',
    logo: matched?.logo || getLogoUrlFromX(matched?.links?.x) || '',
    matchedProjectId: matched ? matched.id : null,
    newsList,
    priority: classifyPriority(raw, newsList),
    checkedAt: new Date().toISOString(),
    raw
  };
}

function matchProject(name) {
  if (!name) return null;
  const n = name.trim().toLowerCase();
  return sidebarProjects.find(p => p.name && p.name.trim().toLowerCase() === n) || null;
}

/**
 * Phân loại độ ưu tiên dựa trên dữ liệu AI trả về (event + news title).
 * Đây KHÔNG phải là việc tự phân tích tin tức — chỉ tổ chức lại kết quả AI đã cho.
 */
function classifyPriority(raw, newsList) {
  if (!newsList || !newsList.length) return 'none';
  const urgentEvents = ['SNAPSHOT', 'TGE_SOON', 'CLAIM_LIVE'];
  const urgentKeywords = /snapshot|claim|tge|delay|deadline|airdrop|listing|mainnet/i;
  const titles = newsList.map(n => n.title || '').join(' ');
  if (urgentEvents.includes(raw.event) || urgentKeywords.test(titles)) return 'critical';
  return 'important';
}

/* ------------------------------------------------------------------ */
/* RENDER RESULTS — stat cards, filter tabs, search/sort, list, pagination
/* ------------------------------------------------------------------ */
function renderCheckNewsResults() {
  const q = (document.getElementById('cn-search')?.value || '').trim().toLowerCase();
  const sortBy = document.getElementById('cn-sort')?.value || 'recent';

  const total = cnResults.length;
  const critical = cnResults.filter(r => r.priority === 'critical').length;
  const important = cnResults.filter(r => r.priority === 'important').length;
  const none = cnResults.filter(r => r.priority === 'none').length;
  const hasNews = critical + important;

  document.getElementById('cn-stat-grid').innerHTML = `
    <div class="cn-stat-card"><div class="cn-stat-value">${total}</div><div class="cn-stat-label">Dự án đã check</div></div>
    <div class="cn-stat-card"><div class="cn-stat-value orange">${hasNews}</div><div class="cn-stat-label">Có tin quan trọng</div></div>
    <div class="cn-stat-card"><div class="cn-stat-value red">${critical}</div><div class="cn-stat-label">Tin rất quan trọng</div></div>
    <div class="cn-stat-card"><div class="cn-stat-value">${none}</div><div class="cn-stat-label">Không có tin mới</div></div>`;

  const tabs = [
    { key: 'all', label: 'Tất cả', count: total },
    { key: 'critical', label: 'Rất quan trọng', count: critical },
    { key: 'important', label: 'Quan trọng', count: important },
    { key: 'none', label: 'Không có tin', count: none }
  ];
  document.getElementById('cn-filter-tabs').innerHTML = tabs.map(t => `
    <button class="cn-filter-tab ${cnFilter === t.key ? 'active' : ''}" onclick="setCnFilter('${t.key}')">
      ${esc(t.label)} <span class="cnt">(${t.count})</span>
    </button>`).join('');

  let list = cnResults.filter(r => {
    if (cnFilter !== 'all' && r.priority !== cnFilter) return false;
    if (q && !r.name.toLowerCase().includes(q)) return false;
    return true;
  });

  const priorityRank = { critical: 0, important: 1, none: 2 };
  list.sort((a, b) => {
    if (sortBy === 'priority') return priorityRank[a.priority] - priorityRank[b.priority];
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    return new Date(b.checkedAt) - new Date(a.checkedAt);
  });

  const totalPages = Math.max(1, Math.ceil(list.length / CN_PAGE_SIZE));
  if (cnPage > totalPages) cnPage = totalPages;
  const pageItems = list.slice((cnPage - 1) * CN_PAGE_SIZE, cnPage * CN_PAGE_SIZE);

  const listEl = document.getElementById('cn-result-list');
  if (!pageItems.length) {
    listEl.innerHTML = `
      <div class="center-empty" style="padding:40px 12px">
        <div class="empty-icon-wrap">${icon('search', 28)}</div>
        <h3>Không có kết quả</h3>
        <p style="font-size:12px">Thử đổi bộ lọc hoặc từ khoá tìm kiếm</p>
      </div>`;
  } else {
    listEl.innerHTML = pageItems.map(r => resultCardHTML(r)).join('');
  }

  renderCnPagination(totalPages, list.length);
}

function resultCardHTML(r) {
  const first = r.newsList[0];
  const headline = first ? (first.title || 'Cập nhật mới') : 'Không có tin tức mới';
  const summary = first ? (first.summary || first.detail || '') : 'Không phát hiện thông tin quan trọng trong khoảng thời gian kiểm tra.';
  const timeLabel = (first && first.date) ? formatRelative(first.date) : formatTimeAgo(r.checkedAt);
  const logoHtml = r.logo
    ? `<img class="cn-result-logo" src="${esc(r.logo)}" onerror="this.style.display='none'">`
    : `<div class="cn-result-logo" style="display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;background:${fallbackColor(r.name)}">${esc((r.name || '?').charAt(0).toUpperCase())}</div>`;

  return `
    <div class="cn-result-card">
      ${logoHtml}
      <div class="cn-result-body">
        <div class="cn-result-row1">
          <span class="cn-result-name">${esc(r.name)}</span>
          ${r.category ? `<span class="cn-result-cat">${esc(r.category)}</span>` : ''}
        </div>
        <div class="cn-result-headline">${esc(headline)}</div>
        ${summary ? `<div class="cn-result-summary">${esc(summary)}</div>` : ''}
        <div class="cn-result-actions">
          <button class="cn-result-btn" onclick="viewResultSource(${r._id})">${icon('externalLink', 13)} View Source</button>
        </div>
      </div>
      <div class="cn-result-meta">
        <span class="cn-priority ${PRIORITY_CLASS[r.priority]}">${PRIORITY_LABEL[r.priority]}</span>
        <span class="cn-result-time">${esc(timeLabel)}</span>
      </div>
    </div>`;
}

function renderCnPagination(totalPages, totalItems) {
  const el = document.getElementById('cn-pagination');
  if (totalPages <= 1) { el.style.display = 'none'; return; }
  el.style.display = 'flex';
  let btns = '';
  for (let i = 1; i <= totalPages; i++) {
    btns += `<button class="page-btn ${i === cnPage ? 'active' : ''}" onclick="goCnPage(${i})">${i}</button>`;
  }
  el.innerHTML = `
    <div class="pagination-info">Trang ${cnPage}/${totalPages} • ${totalItems} kết quả</div>
    <div class="page-btns">
      <button class="page-btn" onclick="goCnPage(${cnPage - 1})" ${cnPage <= 1 ? 'disabled' : ''}>‹</button>
      ${btns}
      <button class="page-btn" onclick="goCnPage(${cnPage + 1})" ${cnPage >= totalPages ? 'disabled' : ''}>›</button>
    </div>`;
}

function goCnPage(p) { cnPage = p; renderCheckNewsResults(); }
function setCnFilter(f) { cnFilter = f; cnPage = 1; renderCheckNewsResults(); }

/* ------------------------------------------------------------------ */
/* VIEW SOURCE
/* ------------------------------------------------------------------ */
function viewResultSource(id) {
  const r = cnResults.find(x => x._id === id);
  if (!r) return;
  const matched = r.matchedProjectId ? sidebarProjects.find(p => p.id === r.matchedProjectId) : null;
  const url = matched?.links?.x || matched?.links?.website || matched?.links?.discord || '';
  if (!url) { toast('Không có nguồn liên kết cho dự án này', 'warn'); return; }
  window.open(url, '_blank', 'noopener');
}

/* ------------------------------------------------------------------ */
/* EXPORT JSON
/* ------------------------------------------------------------------ */
function exportCheckNewsJson() {
  if (!cnResults.length) { toast('Chưa có kết quả để export', 'warn'); return; }
  const data = cnResults.map(r => ({
    project_name: r.name,
    category: r.category,
    priority: r.priority,
    news: r.newsList,
    checked_at: r.checkedAt
  }));
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `check-news-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  toast('Đã export kết quả Check News');
}

/* ------------------------------------------------------------------ */
/* LỊCH SỬ CHECK GẦN NHẤT (localStorage — chỉ để tiện xem lại)
/* ------------------------------------------------------------------ */
function saveLastCheckMeta(meta, timestampIso) {
  try {
    localStorage.setItem(LAST_CHECK_KEY, JSON.stringify({ meta, timestamp: timestampIso, results: cnResults }));
  } catch (e) { /* bỏ qua lỗi quota localStorage */ }
  showLastCheckPanel(timestampIso);
}

function showLastCheckPanel(timestampIso) {
  const panel = document.getElementById('cn-last-check');
  const timeEl = document.getElementById('cn-last-check-time');
  if (!panel || !timeEl) return;
  timeEl.textContent = new Date(timestampIso).toLocaleString('vi-VN');
  panel.style.display = 'flex';
}

function restoreLastCheckMeta() {
  try {
    const raw = localStorage.getItem(LAST_CHECK_KEY);
    if (!raw) return;
    const saved = JSON.parse(raw);
    if (saved?.timestamp) showLastCheckPanel(saved.timestamp);
  } catch (e) { /* ignore */ }
}

function viewLastCheckResults() {
  try {
    const raw = localStorage.getItem(LAST_CHECK_KEY);
    if (!raw) { toast('Chưa có lịch sử check nào', 'warn'); return; }
    const saved = JSON.parse(raw);
    if (!saved?.results?.length) { toast('Không có dữ liệu kết quả đã lưu', 'warn'); return; }

    cnResults = saved.results;
    cnIdCounter = cnResults.reduce((max, r) => Math.max(max, (r._id || 0) + 1), 0);
    cnFilter = 'all';
    cnPage = 1;

    document.getElementById('cn-updated-at').textContent = new Date(saved.timestamp).toLocaleString('vi-VN');
    document.getElementById('cn-empty-state').style.display = 'none';
    document.getElementById('cn-prompt-stage').style.display = 'none';
    document.getElementById('cn-results-stage').style.display = 'block';

    renderCheckNewsResults();
  } catch (e) {
    toast('Không thể tải kết quả đã lưu', 'err');
  }
}
