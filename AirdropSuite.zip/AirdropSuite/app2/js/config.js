/**
 * config.js
 * Cấu hình toàn cục — API Base URL, constants, enums.
 */
const CONFIG = {
  apiBase: localStorage.getItem('ap_api_url') || window.location.origin,
  version: '2.0.0',
  perPage: 50,
  healthInterval: 30000 // ms
};

const EVENT_LABEL = {
  ACTIVE: 'ACTIVE',
  SNAPSHOT: 'SNAPSHOT SOON',
  TGE_SOON: 'TGE SOON',
  CLAIM_LIVE: 'CLAIM LIVE',
  ENDED: 'ENDED'
};

const EVENT_CLASS = {
  ACTIVE: 'active',
  SNAPSHOT: 'snapshot',
  TGE_SOON: 'tge',
  CLAIM_LIVE: 'claim',
  ENDED: 'ended'
};

/* Check News — mức độ ưu tiên của tin tức sau khi đọc kết quả AI */
const PRIORITY_LABEL = {
  critical: 'Rất quan trọng',
  important: 'Quan trọng',
  none: 'Không có tin mới'
};

const PRIORITY_CLASS = {
  critical: 'critical',
  important: 'important',
  none: 'none'
};
