/**
 * dashboard-editor.js
 * Các tính năng chỉnh sửa "analysis" của 1 project trong Dashboard:
 *  - Roadmap: milestones dạng timeline, tích tròn để đánh dấu hoàn thành, thêm/sửa/xoá.
 *  - Important Events: danh sách sự kiện (ngày + tóm tắt + link), thêm/sửa/xoá.
 *  - Tokenomics: chọn ảnh PNG từ máy (base64), xoá ảnh.
 *  - AI Assist: sinh Prompt xin AI điền chi tiết dự án + Import JSON để lưu.
 *
 * Thông tin gốc của Project (tên, logo, category, links, event, favorite) luôn
 * đến từ App 1 — không đổi ở đây. Chỉ trường `analysis` được ghi lại qua
 * API /api/import sẵn có (upsert theo id), merge an toàn — không đụng tới
 * các field analysis khác ngoài field đang sửa.
 */

/* ------------------------------------------------------------------ */
/* SHARED SAVE HELPER
/* ------------------------------------------------------------------ */
async function patchProjectAnalysis(projectId, mutateFn, successMsg) {
  const existing = sidebarProjects.find(p => p.id === projectId);
  if (!existing) { toast('Không tìm thấy dự án', 'err'); return false; }

  const mergedAnalysis = deepMerge({}, existing.analysis || {});
  mutateFn(mergedAnalysis);

  const payload = {
    id: existing.id,
    category: existing.category,
    name: existing.name,
    logo: existing.logo,
    links: existing.links,
    tasks: existing.tasks,
    favorite: existing.favorite,
    event: existing.event,      // giữ nguyên — App 1 quản lý
    analysis: mergedAnalysis
  };

  try {
    await apiPostImport([payload]);
    existing.analysis = mergedAnalysis; // cập nhật cache cục bộ ngay, tránh phải reload toàn bộ
    if (typeof renderSidebar === 'function') renderSidebar(); // đồng bộ sidebar ngay (progress/score có thể đã đổi)
    if (successMsg) toast(successMsg);
    return true;
  } catch (err) {
    toast('Lưu lỗi: ' + err.message, 'err');
    return false;
  }
}

function recomputeRoadmapSummary(analysis) {
  const list = Array.isArray(analysis.roadmap?.milestones_list) ? analysis.roadmap.milestones_list : [];
  const done = list.filter(m => m.done).length;
  const total = list.length;
  if (!analysis.roadmap) analysis.roadmap = {};
  analysis.roadmap.progress = total ? Math.round((done / total) * 100) : 0;
  analysis.roadmap.milestones = total ? `${done} / ${total}` : '';
}

/* ------------------------------------------------------------------ */
/* ROADMAP — milestones timeline, click tròn để tick, thêm/sửa/xoá
/* ------------------------------------------------------------------ */
function renderRoadmapCard(p) {
  const list = safeGet(p, 'analysis.roadmap.milestones_list', []);
  const el = document.getElementById('roadmap-milestones');

  const done = list.filter(m => m.done).length;
  const total = list.length;
  const pct = total ? Math.round((done / total) * 100) : 0;
  document.getElementById('roadmap-card-bar').style.width = pct + '%';
  document.getElementById('roadmap-card-pct').textContent = pct + '%';
  document.getElementById('roadmap-card-sub').textContent = total ? `${done}/${total} mốc hoàn thành` : 'Chưa có cột mốc nào';

  if (!total) {
    el.innerHTML = `<div class="rm-empty">Chưa có<br><span>Chưa thêm cột mốc nào cho dự án này.</span></div>`;
    return;
  }

  el.innerHTML = list.map((m, idx) => `
    <div class="rm-item">
      <button class="rm-toggle ${m.done ? 'done' : ''}" onclick="toggleMilestone('${esc(p.id)}', ${idx})" title="${m.done ? 'Bỏ đánh dấu' : 'Đánh dấu hoàn thành'}">
        ${icon(m.done ? 'checkCircle' : 'circle', 18)}
      </button>
      <span class="rm-label ${m.done ? 'done' : ''}">${esc(m.label)}</span>
      <div class="rm-actions">
        <button class="rm-icon-btn" onclick="openMilestoneModal('${esc(p.id)}', ${idx})" title="Sửa">${icon('edit', 13)}</button>
        <button class="rm-icon-btn" onclick="deleteMilestone('${esc(p.id)}', ${idx})" title="Xoá">${icon('x', 13)}</button>
      </div>
    </div>`).join('');
}

async function toggleMilestone(projectId, index) {
  await patchProjectAnalysis(projectId, (a) => {
    const list = Array.isArray(a.roadmap?.milestones_list) ? a.roadmap.milestones_list : [];
    if (!list[index]) return;
    list[index].done = !list[index].done;
    a.roadmap.milestones_list = list;
    recomputeRoadmapSummary(a);
  }, 'Đã cập nhật cột mốc');
  renderDashboard(selectedProjectId);
}

let milestoneModalState = { projectId: null, index: -1 };

function openMilestoneModal(projectId, index = -1) {
  milestoneModalState = { projectId, index };
  const p = sidebarProjects.find(x => x.id === projectId);
  const list = safeGet(p, 'analysis.roadmap.milestones_list', []);
  const m = index >= 0 ? list[index] : null;
  document.getElementById('milestone-modal-title').textContent = index >= 0 ? 'Sửa cột mốc' : 'Thêm cột mốc';
  document.getElementById('milestone-input-label').value = m ? m.label : '';
  document.getElementById('milestone-input-done').checked = !!(m && m.done);
  document.getElementById('milestone-modal').style.display = 'flex';
}
function closeMilestoneModal() { document.getElementById('milestone-modal').style.display = 'none'; }
function closeMilestoneModalOnBg(e) { if (e.target.id === 'milestone-modal') closeMilestoneModal(); }

async function saveMilestoneModal() {
  const label = document.getElementById('milestone-input-label').value.trim();
  if (!label) { toast('Vui lòng nhập tên cột mốc', 'warn'); return; }
  const done = document.getElementById('milestone-input-done').checked;
  const { projectId, index } = milestoneModalState;

  await patchProjectAnalysis(projectId, (a) => {
    if (!a.roadmap) a.roadmap = {};
    const list = Array.isArray(a.roadmap.milestones_list) ? a.roadmap.milestones_list : [];
    if (index >= 0 && list[index]) {
      list[index].label = label;
      list[index].done = done;
    } else {
      list.push({ id: genLocalId(), label, done });
    }
    a.roadmap.milestones_list = list;
    recomputeRoadmapSummary(a);
  }, 'Đã lưu cột mốc');

  closeMilestoneModal();
  renderDashboard(selectedProjectId);
}

async function deleteMilestone(projectId, index) {
  await patchProjectAnalysis(projectId, (a) => {
    const list = Array.isArray(a.roadmap?.milestones_list) ? a.roadmap.milestones_list : [];
    list.splice(index, 1);
    a.roadmap.milestones_list = list;
    recomputeRoadmapSummary(a);
  }, 'Đã xoá cột mốc');
  renderDashboard(selectedProjectId);
}

/* ------------------------------------------------------------------ */
/* IMPORTANT EVENTS — dùng chung mảng analysis.news (title/summary/date/link)
/* ------------------------------------------------------------------ */
function renderImportantEvents(p) {
  const el = document.getElementById('important-events-list');
  const news = safeGet(p, 'analysis.news', []);
  const list = Array.isArray(news) ? news : [];

  if (!list.length) {
    el.innerHTML = `<div class="rm-empty">Chưa có<br><span>Chưa ghi nhận sự kiện quan trọng nào.</span></div>`;
    return;
  }

  el.innerHTML = list.map((n, idx) => `
    <div class="ev-item">
      <div class="ev-date">${esc(n.date || '—')}</div>
      <div class="ev-body">
        <div class="ev-summary">${esc(n.summary || n.title || 'Sự kiện')}</div>
      </div>
      <div class="ev-actions">
        ${n.link ? `<button class="ev-icon-btn" onclick="window.open('${esc(n.link)}','_blank','noopener')" title="Xem bài viết">${icon('externalLink', 13)}</button>` : ''}
        <button class="ev-icon-btn" onclick="openEventModal('${esc(p.id)}', ${idx})" title="Sửa">${icon('edit', 13)}</button>
        <button class="ev-icon-btn" onclick="deleteEvent('${esc(p.id)}', ${idx})" title="Xoá">${icon('x', 13)}</button>
      </div>
    </div>`).join('');
}

let eventModalState = { projectId: null, index: -1 };

function openEventModal(projectId, index = -1) {
  eventModalState = { projectId, index };
  const p = sidebarProjects.find(x => x.id === projectId);
  const news = safeGet(p, 'analysis.news', []);
  const n = index >= 0 ? news[index] : null;
  document.getElementById('event-modal-title').textContent = index >= 0 ? 'Sửa sự kiện' : 'Thêm sự kiện';
  document.getElementById('event-input-date').value = n ? (n.date || '') : '';
  document.getElementById('event-input-summary').value = n ? (n.summary || n.title || '') : '';
  document.getElementById('event-input-link').value = n ? (n.link || '') : '';
  document.getElementById('event-modal').style.display = 'flex';
}
function closeEventModal() { document.getElementById('event-modal').style.display = 'none'; }
function closeEventModalOnBg(e) { if (e.target.id === 'event-modal') closeEventModal(); }

async function saveEventModal() {
  const date = document.getElementById('event-input-date').value.trim();
  const summary = document.getElementById('event-input-summary').value.trim();
  const link = document.getElementById('event-input-link').value.trim();
  if (!summary) { toast('Vui lòng nhập tóm tắt nội dung', 'warn'); return; }
  const { projectId, index } = eventModalState;

  await patchProjectAnalysis(projectId, (a) => {
    const list = Array.isArray(a.news) ? a.news : [];
    const item = { title: summary, summary, date, link };
    if (index >= 0 && list[index]) list[index] = item;
    else list.unshift(item);
    a.news = list;
  }, 'Đã lưu sự kiện');

  closeEventModal();
  renderDashboard(selectedProjectId);
}

async function deleteEvent(projectId, index) {
  await patchProjectAnalysis(projectId, (a) => {
    const list = Array.isArray(a.news) ? a.news : [];
    list.splice(index, 1);
    a.news = list;
  }, 'Đã xoá sự kiện');
  renderDashboard(selectedProjectId);
}

/* ------------------------------------------------------------------ */
/* TOKENOMICS — chọn ảnh PNG từ máy (đọc base64, không cần backend upload)
/* ------------------------------------------------------------------ */
function renderTokenomicsCard(p) {
  const el = document.getElementById('tokenomics-content');
  const tk = safeGet(p, 'analysis.tokenomics', null);
  const imgUrl = (tk && typeof tk === 'object') ? (tk.image || '') : '';

  if (imgUrl) {
    el.innerHTML = `
      <img src="${esc(imgUrl)}" alt="Tokenomics" onerror="this.parentNode.innerHTML=TOKENOMICS_EMPTY_HTML">
      <div class="tokenomics-actions">
        <button class="btn" onclick="triggerTokenomicsFilePicker()">${icon('image', 13)} Đổi ảnh</button>
        <button class="btn" onclick="removeTokenomicsImage('${esc(p.id)}')">${icon('x', 13)} Xoá ảnh</button>
      </div>`;
  } else {
    el.innerHTML = `
      <div class="tokenomics-empty">
        ${icon('image', 32)}
        <div>Chưa có</div>
        <span>Chưa thêm hình ảnh Tokenomics</span>
        <button class="btn btn-primary" style="margin-top:12px" onclick="triggerTokenomicsFilePicker()">${icon('image', 13)} Chọn ảnh từ máy</button>
      </div>`;
  }
}

const TOKENOMICS_EMPTY_HTML = `
  <div class="tokenomics-empty">
    ${icon('image', 32)}
    <div>Chưa có</div>
    <span>Chưa thêm hình ảnh Tokenomics</span>
    <button class="btn btn-primary" style="margin-top:12px" onclick="triggerTokenomicsFilePicker()">${icon('image', 13)} Chọn ảnh từ máy</button>
  </div>`;

function triggerTokenomicsFilePicker() {
  document.getElementById('tokenomics-file-input').click();
}

function handleTokenomicsFileChange(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/')) { toast('Vui lòng chọn file hình ảnh', 'warn'); input.value = ''; return; }
  if (file.size > 4 * 1024 * 1024) { toast('Ảnh quá lớn (>4MB), vui lòng chọn ảnh nhỏ hơn', 'warn'); input.value = ''; return; }

  const reader = new FileReader();
  reader.onload = async () => {
    const dataUrl = reader.result;
    await patchProjectAnalysis(selectedProjectId, (a) => {
      if (!a.tokenomics || typeof a.tokenomics !== 'object') a.tokenomics = {};
      a.tokenomics.image = dataUrl;
    }, 'Đã cập nhật ảnh Tokenomics');
    input.value = '';
    renderDashboard(selectedProjectId);
  };
  reader.onerror = () => toast('Không đọc được file ảnh', 'err');
  reader.readAsDataURL(file);
}

async function removeTokenomicsImage(projectId) {
  await patchProjectAnalysis(projectId, (a) => {
    if (a.tokenomics && typeof a.tokenomics === 'object') a.tokenomics.image = '';
  }, 'Đã xoá ảnh Tokenomics');
  renderDashboard(selectedProjectId);
}

/* ------------------------------------------------------------------ */
/* AI ASSIST — Prompt AI (điền chi tiết dự án) + Import JSON
/* ------------------------------------------------------------------ */
function buildDashboardDetailPrompt(p) {
  const link = p.links?.x || p.links?.website || '(chưa có link — vui lòng bổ sung X hoặc Website)';
  return `Bạn là một chuyên gia phân tích Crypto Airdrop.

Hãy nghiên cứu kỹ dự án dưới đây và điền đầy đủ thông tin chi tiết.

Tên dự án: ${p.name}
Link chính thức (X/Twitter hoặc Website): ${link}

Vai trò: Chỉ lấy thông tin chính xác từ đúng nguồn chính thức của dự án nêu trên, tuyệt đối không bịa tin, không nhầm sang dự án khác cùng tên.

Yêu cầu trả về đúng 1 object JSON theo cấu trúc sau:
{
  "project_name": "${esc(p.name)}",
  "category": "${esc(p.category || 'TESTNET')}",
  "event": "ACTIVE / SNAPSHOT / TGE_SOON / CLAIM_LIVE / ENDED",
  "analysis": {
    "score": <number 0-100>,
    "info": { "description": "...", "chain": "...", "type": "..." },
    "funding": { "total": "$X", "round": "Seed" },
    "backers": ["Backer 1", "Backer 2"],
    "roadmap": {
      "progress": <percent>,
      "milestones": "X / Y",
      "milestones_list": [{"label": "Tên cột mốc", "done": true}]
    },
    "tokenomics": { "tge": "Q4 2026", "utility": "..." },
    "community": { "score": <number>, "followers": "...", "discord": "..." },
    "development": { "score": <number>, "status": "..." },
    "news": [{"title": "Tóm tắt sự kiện", "date": "YYYY-MM-DD", "link": "https://..."}],
    "ai_analysis": { "overall": "...", "summary": "..." },
    "notes": "..."
  }
}

Lưu ý:
- "roadmap.milestones_list" là DANH SÁCH các cột mốc cụ thể (càng chi tiết càng tốt), có thể để trống nếu không xác định được.
- "news" chỉ gồm các bài viết/sự kiện QUAN TRỌNG, kèm link bài viết gốc nếu có.
- Chỉ trả về JSON hợp lệ, không thêm Markdown.
- Chỉ lấy thông tin chính xác từ nguồn chính thức, không được bịa tin.`;
}

function openDashboardPromptModal() {
  const p = sidebarProjects.find(x => x.id === selectedProjectId);
  if (!p) { toast('Vui lòng chọn 1 dự án trước', 'warn'); return; }
  document.getElementById('dashboard-prompt-output').value = buildDashboardDetailPrompt(p);
  document.getElementById('dashboard-prompt-modal').style.display = 'flex';
}
function closeDashboardPromptModal() { document.getElementById('dashboard-prompt-modal').style.display = 'none'; }
function closeDashboardPromptModalOnBg(e) { if (e.target.id === 'dashboard-prompt-modal') closeDashboardPromptModal(); }

function copyDashboardPrompt() {
  const ta = document.getElementById('dashboard-prompt-output');
  ta.select();
  ta.setSelectionRange(0, 999999);
  try { document.execCommand('copy'); toast('Đã copy prompt!'); }
  catch (e) { navigator.clipboard?.writeText(ta.value).then(() => toast('Đã copy prompt!')); }
}

function openDashboardImportModal() {
  if (!selectedProjectId) { toast('Vui lòng chọn 1 dự án trước', 'warn'); return; }
  document.getElementById('dashboard-import-input').value = '';
  document.getElementById('dashboard-import-modal').style.display = 'flex';
}
function closeDashboardImportModal() { document.getElementById('dashboard-import-modal').style.display = 'none'; }
function closeDashboardImportModalOnBg(e) { if (e.target.id === 'dashboard-import-modal') closeDashboardImportModal(); }

/**
 * Lưu JSON AI trả về cho ĐÚNG project đang chọn.
 * - info/funding/backers/community/development/ai_analysis/tokenomics.tge/utility -> GHI ĐÈ (người dùng chủ động yêu cầu AI điền lại).
 * - tokenomics.image -> giữ nguyên (ảnh do người dùng tự chọn, JSON không đụng tới).
 * - roadmap.milestones_list -> GHI ĐÈ nếu AI có trả về (đồng thời tính lại progress/milestones); nếu không có thì giữ nguyên danh sách cũ.
 * - news (Important Events) -> chỉ MERGE thêm (không xoá sự kiện đã có / đã tự thêm tay).
 */
async function saveDashboardImport() {
  const raw = (document.getElementById('dashboard-import-input').value || '').trim();
  if (!raw) { toast('Vui lòng dán JSON kết quả AI', 'warn'); return; }

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    toast('JSON không hợp lệ: ' + e.message, 'err');
    return;
  }
  const obj = Array.isArray(parsed) ? parsed[0] : parsed;
  if (!obj || typeof obj !== 'object') { toast('Không tìm thấy dữ liệu hợp lệ trong JSON', 'warn'); return; }

  const aiAnalysis = obj.analysis || {};
  const projectId = selectedProjectId;

  const ok = await patchProjectAnalysis(projectId, (a) => {
    if (aiAnalysis.score !== undefined) a.score = aiAnalysis.score;
    if (aiAnalysis.info) a.info = aiAnalysis.info;
    if (aiAnalysis.funding) a.funding = aiAnalysis.funding;
    if (Array.isArray(aiAnalysis.backers)) a.backers = aiAnalysis.backers;
    if (aiAnalysis.community) a.community = aiAnalysis.community;
    if (aiAnalysis.development) a.development = aiAnalysis.development;
    if (aiAnalysis.ai_analysis) a.ai_analysis = aiAnalysis.ai_analysis;
    if (typeof aiAnalysis.notes === 'string') a.notes = aiAnalysis.notes;

    // Tokenomics: chỉ cập nhật tge/utility, KHÔNG đụng tới ảnh đã chọn
    if (aiAnalysis.tokenomics) {
      if (!a.tokenomics || typeof a.tokenomics !== 'object') a.tokenomics = {};
      const keepImage = a.tokenomics.image || '';
      a.tokenomics = { ...a.tokenomics, ...aiAnalysis.tokenomics, image: keepImage };
    }

    // Roadmap: nếu AI trả về milestones_list thì ghi đè + tính lại progress
    if (aiAnalysis.roadmap) {
      if (!a.roadmap) a.roadmap = {};
      if (Array.isArray(aiAnalysis.roadmap.milestones_list)) {
        a.roadmap.milestones_list = aiAnalysis.roadmap.milestones_list.map(m => ({
          id: genLocalId(), label: m.label || m.name || 'Mốc', done: !!m.done
        }));
        recomputeRoadmapSummary(a);
      } else if (aiAnalysis.roadmap.progress !== undefined || aiAnalysis.roadmap.milestones !== undefined) {
        if (aiAnalysis.roadmap.progress !== undefined) a.roadmap.progress = aiAnalysis.roadmap.progress;
        if (aiAnalysis.roadmap.milestones !== undefined) a.roadmap.milestones = aiAnalysis.roadmap.milestones;
      }
    }

    // Important Events (news): chỉ MERGE thêm, không xoá sự kiện đã có
    if (Array.isArray(aiAnalysis.news) && aiAnalysis.news.length) {
      const existingNews = Array.isArray(a.news) ? a.news : [];
      const fresh = aiAnalysis.news.filter(n => n && (n.title || n.summary) &&
        !existingNews.some(e => (e.title === (n.title || n.summary)) && e.date === n.date));
      a.news = [...fresh.map(n => ({ title: n.title || n.summary, summary: n.summary || n.title, date: n.date || '', link: n.link || '' })), ...existingNews];
    }
  }, 'Đã lưu chi tiết dự án từ JSON');

  if (ok) {
    closeDashboardImportModal();
    renderDashboard(projectId);
  }
}
