/**
 * dashboard.js
 * Render center panel — project header, summary cards, và điều phối các card
 * có thể chỉnh sửa (Roadmap / Important Events / Tokenomics) nằm ở dashboard-editor.js.
 * Thông tin gốc (tên, logo, category, links, event) vẫn đến từ App 1 — chỉ đọc.
 * Dữ liệu phân tích (analysis.*) có thể chỉnh sửa tại đây.
 */

let lastRenderedProjectId = null;

function renderDashboard(projectId) {
  const p = sidebarProjects.find(x => x.id === projectId);
  const empty = document.getElementById('center-empty');
  const content = document.getElementById('center-content');
  if (!p) { empty.style.display = 'flex'; content.style.display = 'none'; return; }

  empty.style.display = 'none';
  content.style.display = 'block';

  const isProjectChange = projectId !== lastRenderedProjectId;
  lastRenderedProjectId = projectId;

  // Header
  const logoUrl = p.logo || getLogoUrlFromX(p.links?.x);
  const phLogo = document.getElementById('ph-logo');
  phLogo.src = logoUrl || '';
  phLogo.style.display = 'block';
  phLogo.onerror = function() {
    this.style.display = 'none';
    const fb = document.createElement('div');
    fb.className = 'ph-logo';
    fb.style.display = 'flex';
    fb.style.alignItems = 'center';
    fb.style.justifyContent = 'center';
    fb.style.fontSize = '24px';
    fb.style.fontWeight = '800';
    fb.style.color = '#fff';
    fb.style.background = fallbackColor(p.name);
    fb.textContent = (p.name || '?').charAt(0).toUpperCase();
    this.parentNode.insertBefore(fb, this);
  };

  document.getElementById('ph-name').textContent = p.name;
  const eventEl = document.getElementById('ph-event');
  eventEl.textContent = EVENT_LABEL[p.event] || p.event;
  eventEl.className = 'ph-badge ' + (EVENT_CLASS[p.event] || 'active');

  const favBtn = document.getElementById('ph-fav');
  favBtn.innerHTML = icon('star', 20);
  favBtn.className = 'ph-fav ' + (p.favorite ? 'on' : '');

  // Tags
  const tags = [];
  if (p.category) tags.push(p.category);
  const chain = safeGet(p, 'analysis.info.chain', '');
  if (chain) tags.push(chain);
  const type = safeGet(p, 'analysis.info.type', '');
  if (type) tags.push(type);
  const status = safeGet(p, 'analysis.info.status', '');
  if (status) tags.push(status);
  document.getElementById('ph-tags').innerHTML = tags.map(t => `<span class="ph-tag">${esc(t)}</span>`).join('');

  // Links
  setLink('ph-link-website', p.links?.website);
  setLink('ph-link-x', p.links?.x);
  setLink('ph-link-discord', p.links?.discord);
  setLink('ph-link-docs', p.links?.docs);
  const cta = document.getElementById('ph-cta');
  if (p.links?.website) { cta.href = p.links.website; cta.style.display = 'inline-flex'; }
  else { cta.style.display = 'none'; }

  // Summary Cards (Tổng quan — giữ nguyên)
  const progress = safeGet(p, 'analysis.roadmap.progress', 0);
  document.getElementById('sum-roadmap').textContent = progress + '%';
  document.getElementById('sum-roadmap').className = 'sum-value green';
  document.getElementById('sum-roadmap-bar').style.width = progress + '%';
  const stage = safeGet(p, 'analysis.roadmap.milestones', '');
  document.getElementById('sum-roadmap-sub').textContent = stage ? `Current Stage: ${stage}` : '—';

  const funding = safeGet(p, 'analysis.funding.total', '—');
  document.getElementById('sum-funding').textContent = funding;
  document.getElementById('sum-funding-sub').textContent = safeGet(p, 'analysis.funding.round', '—');

  const backers = safeGet(p, 'analysis.backers', []);
  document.getElementById('sum-backers').textContent = backers.length;
  document.getElementById('sum-backers-sub').textContent = backers.length ? 'Top Backers' : '—';
  const avatars = backers.slice(0, 3).map((b, i) => `<div class="backer-avatar" style="z-index:${3-i}">${esc(String(b).charAt(0).toUpperCase())}</div>`).join('');
  document.getElementById('sum-backers-avatars').innerHTML = avatars;

  const score = safeGet(p, 'analysis.score', null);
  document.getElementById('sum-score').textContent = score !== null ? score + '/100' : '—';
  const starCount = score !== null ? Math.round(score / 20) : 0;
  document.getElementById('sum-stars').innerHTML = score !== null
    ? Array.from({ length: 5 }, (_, i) => icon('star', 13, i < starCount ? '' : 'style="opacity:.25"')).join('')
    : '';
  document.getElementById('sum-score-sub').textContent = score >= 80 ? 'Excellent' : score >= 60 ? 'Good' : score !== null ? 'Average' : '—';

  const tge = safeGet(p, 'analysis.tokenomics.tge', safeGet(p, 'analysis.roadmap.expected_tge', '—'));
  document.getElementById('sum-tge').textContent = tge;
  document.getElementById('sum-tge-sub').textContent = safeGet(p, 'analysis.roadmap.tge_window', '—');

  // Roadmap (editable) + Important Events (editable) + Tokenomics (editable) — xem dashboard-editor.js
  renderRoadmapCard(p);
  renderImportantEvents(p);
  renderTokenomicsCard(p);

  // Reset Detail card về trạng thái đóng mỗi khi chọn project mới (mặc định đóng)
  if (isProjectChange) {
    openAccordionIndex = -1;
    editingAccordionKey = null;
    document.getElementById('detail-card').classList.remove('open');
  }
  renderAccordion(p);
}

function setLink(id, url) {
  const el = document.getElementById(id);
  if (url) { el.href = url; el.style.display = 'inline-flex'; }
  else { el.style.display = 'none'; }
}

function toggleSelectedFavorite() {
  // Favorite / danh sách Project vẫn do App 1 quản lý — App 2 chỉ chỉnh phần Phân tích (analysis).
  toast('Trạng thái Favorite được quản lý ở App 1.', 'warn');
}
