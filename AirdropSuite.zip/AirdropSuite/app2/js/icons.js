/**
 * icons.js
 * Bộ icon SVG dùng chung — thay thế toàn bộ emoji để giao diện đồng bộ,
 * chuyên nghiệp (phong cách stroke 2px, giống Lucide/Heroicons).
 * Dùng: icon('map', 16) -> trả về chuỗi HTML <svg>...</svg>
 */
const ICONS = {
  dashboard: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  newspaper: '<path d="M4 4h13a2 2 0 0 1 2 2v13a1 1 0 0 1-1.7.7L15 17H6a2 2 0 0 1-2-2z"/><path d="M4 4v13a2 2 0 0 1-2 2"/><line x1="8" y1="8" x2="13" y2="8"/><line x1="8" y1="11.5" x2="13" y2="11.5"/><line x1="8" y1="15" x2="11" y2="15"/>',
  bot: '<rect x="4" y="9" width="16" height="11" rx="2.5"/><path d="M12 9V5"/><circle cx="12" cy="3.5" r="1.5"/><line x1="9" y1="14" x2="9" y2="15.5"/><line x1="15" y1="14" x2="15" y2="15.5"/><path d="M2 13h2"/><path d="M20 13h2"/>',
  info: '<circle cx="12" cy="12" r="9"/><line x1="12" y1="11" x2="12" y2="16.5"/><circle cx="12" cy="7.7" r="0.9" fill="currentColor" stroke="none"/>',
  wallet: '<path d="M20 7H5a2 2 0 0 1 0-4h13v4"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1h-4a2.5 2.5 0 0 1 0-5h4a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1H5"/>',
  map: '<polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/><line x1="9" y1="3" x2="9" y2="18"/><line x1="15" y1="6" x2="15" y2="21"/>',
  users: '<circle cx="9" cy="8" r="3.2"/><path d="M2.5 20c0-3.6 2.9-6.2 6.5-6.2s6.5 2.6 6.5 6.2"/><circle cx="17" cy="8.5" r="2.6"/><path d="M15.8 14c2.7.5 4.7 2.7 4.7 6"/>',
  code: '<polyline points="9 8 4 12.5 9 17"/><polyline points="15 8 20 12.5 15 17"/>',
  pieChart: '<path d="M12 3v9l7.7 4.5"/><path d="M20.9 13.5A9 9 0 1 1 12 3"/>',
  sparkles: '<path d="M12 3l1.6 4.7L18 9.3l-4.4 1.6L12 15.6l-1.6-4.7L6 9.3l4.4-1.6z"/><path d="M5 17.5l.8 2.3 2.3.8-2.3.8-.8 2.3-.8-2.3-2.3-.8 2.3-.8z"/><path d="M19 15.5l.6 1.7 1.7.6-1.7.6-.6 1.7-.6-1.7-1.7-.6 1.7-.6z"/>',
  fileText: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/>',
  chevronDown: '<polyline points="6 9 12 15 18 9"/>',
  chevronRight: '<polyline points="9 6 15 12 9 18"/>',
  checkCircle: '<circle cx="12" cy="12" r="9"/><polyline points="8 12.5 11 15.5 16 9"/>',
  alertTriangle: '<path d="M12 3.5 22 20H2z"/><line x1="12" y1="10" x2="12" y2="14.5"/><circle cx="12" cy="17.3" r="0.9" fill="currentColor" stroke="none"/>',
  circle: '<circle cx="12" cy="12" r="8"/>',
  download: '<path d="M12 3v13"/><polyline points="6 11 12 17 18 11"/><path d="M4 20h16"/>',
  upload: '<path d="M12 20V7"/><polyline points="6 12 12 6 18 12"/><path d="M4 20h16"/>',
  copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9.5" r="1.6"/><path d="M21 16l-5.5-5.5a1.6 1.6 0 0 0-2.2 0L4 19"/>',
  package: '<path d="M21 8.5v7l-9 4.7-9-4.7v-7L12 3.8z"/><polyline points="3.3 7.9 12 12.6 20.7 7.9"/><line x1="12" y1="12.6" x2="12" y2="21.4"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><line x1="21" y1="21" x2="15.4" y2="15.4"/>',
  star: '<polygon points="12 2.5 15.1 8.7 22 9.7 17 14.6 18.2 21.5 12 18.2 5.8 21.5 7 14.6 2 9.7 8.9 8.7"/>',
  clock: '<circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15.5 14"/>',
  warning: '<path d="M12 3.5 22 20H2z"/><line x1="12" y1="10" x2="12" y2="14.5"/><circle cx="12" cy="17.3" r="0.9" fill="currentColor" stroke="none"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  refresh: '<path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 21h5v-5"/>',
  layers: '<polygon points="12 2 22 8 12 14 2 8"/><polyline points="2 13 12 19 22 13"/><polyline points="2 17.5 12 23.5 22 17.5"/>',
  archive: '<rect x="3" y="4" width="18" height="4.5" rx="1"/><path d="M4.5 8.5V19a1.5 1.5 0 0 0 1.5 1.5h12a1.5 1.5 0 0 0 1.5-1.5V8.5"/><line x1="10" y1="12.5" x2="14" y2="12.5"/>',
  rocket: '<path d="M13.5 2.5c3 0 6 3 6 6-1 3-4 6.5-6 8-1.5-1.5-3-3.5-3-3.5s-2-1.5-3.5-3c1.5-2 5-6.5 8-8z"/><path d="M8 15l-3.5 3.5"/><path d="M9 19c-2 .5-4 0-5-1s-1.5-3-1-5c2 0 4 1 5 2"/><circle cx="15" cy="8" r="1.4" fill="currentColor" stroke="none"/>',
  externalLink: '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/>',
};

/**
 * Trả về HTML string của icon.
 * @param {string} name - key trong ICONS
 * @param {number} size - kích thước px
 * @param {string} extraAttrs - thuộc tính bổ sung (vd: 'class="..."')
 */
function icon(name, size = 16, extraAttrs = '') {
  const body = ICONS[name];
  if (!body) return '';
  return `<svg ${extraAttrs} width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`;
}
