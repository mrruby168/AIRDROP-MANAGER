/**
 * prompt-builder.js
 * Sinh Prompt (text) để người dùng copy sang công cụ AI ngoài (ChatGPT, Claude…).
 * Không tự gọi AI — chỉ tạo prompt + đọc kết quả AI dán vào (xem checknews.js).
 */

let cnLastPromptMeta = null; // { mode, source, cats, onlyFav }

function buildCheckConfig() {
  const modeInput = document.querySelector('input[name="check-mode"]:checked');
  const sourceInput = document.querySelector('input[name="check-source"]:checked');
  const onlyFav = document.getElementById('cn-only-favorite')?.checked || false;
  const cats = [];
  if (document.getElementById('prompt-cat-testnet')?.checked) cats.push('Testnet');
  if (document.getElementById('prompt-cat-depin')?.checked) cats.push('DePIN');
  return {
    mode: modeInput ? modeInput.value : 'news',
    source: sourceInput ? sourceInput.value : 'x',
    cats,
    onlyFav
  };
}

function generatePromptAndCheck() {
  const cfg = buildCheckConfig();
  if (!cfg.cats.length) {
    toast('Vui lòng chọn ít nhất 1 danh mục (Testnet/DePIN)', 'warn');
    return;
  }

  const projects = getSelectedCheckProjects();
  if (!projects.length) {
    toast('Không có dự án nào phù hợp để check', 'warn');
    return;
  }

  const text = generatePromptText(cfg.mode, cfg.source, cfg.cats) +
    `\n\nDanh sách dự án cần check (${projects.length}):\n` +
    projects.map(p => {
      const link = p.links?.x || p.links?.website || '(chưa có link — cần bổ sung X hoặc Website)';
      return `- ${p.name} | Link: ${link}`;
    }).join('\n');

  cnLastPromptMeta = cfg;
  document.getElementById('cn-prompt-output').value = text;
  document.getElementById('cn-ai-result-input').value = '';

  document.getElementById('cn-empty-state').style.display = 'none';
  document.getElementById('cn-results-stage').style.display = 'none';
  document.getElementById('cn-prompt-stage').style.display = 'block';
}

function copyGeneratedPrompt() {
  const ta = document.getElementById('cn-prompt-output');
  if (!ta || !ta.value) { toast('Chưa có prompt để copy', 'warn'); return; }
  ta.select();
  ta.setSelectionRange(0, 999999);
  try {
    document.execCommand('copy');
    toast('Đã copy prompt!');
  } catch (e) {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(ta.value).then(() => toast('Đã copy prompt!'));
    } else {
      toast('Không thể copy, vui lòng copy thủ công', 'warn');
    }
  }
}
