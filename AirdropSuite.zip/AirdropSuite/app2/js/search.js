/**
 * search.js
 * Xử lý search realtime — debounce + render sidebar.
 */

let searchTimer = null;

function initSearch() {
  const input = document.getElementById('global-search');
  input.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
      renderSidebar();
    }, 150);
  });

  // Keyboard shortcut ⌘K / Ctrl+K
  document.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
      e.preventDefault();
      input.focus();
    }
  });
}
