/**
 * sidebar.js
 * Render danh sách project ở left sidebar (Dashboard, Read Only), filter, sort, search.
 */

let sidebarProjects = [];
let selectedProjectId = null;

function renderSidebar() {
  const listEl = document.getElementById('project-list');
  const q = (document.getElementById('global-search').value || '').trim().toLowerCase();
  const sortBy = document.getElementById('sort-by').value;
  const favOnly = document.getElementById('filter-fav').checked;
  const eventFilter = document.getElementById('filter-event').value;
  const catDePIN = document.getElementById('filter-cat-depin').checked;
  const catTestnet = document.getElementById('filter-cat-testnet').checked;

  let list = sidebarProjects.filter(p => {
    if (q && !p.name.toLowerCase().includes(q)) return false;
    if (favOnly && !p.favorite) return false;
    if (eventFilter && p.event !== eventFilter) return false;
    const catOk = (catDePIN && p.category === 'DEPIN') || (catTestnet && p.category === 'TESTNET');
    if (!catOk) return false;
    return true;
  });

  list.sort((a, b) => {
    if (sortBy === 'score') {
      const sa = safeGet(a, 'analysis.score', 0);
      const sb = safeGet(b, 'analysis.score', 0);
      return sb - sa;
    }
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    if (sortBy === 'funding') {
      const fa = parseFloat(safeGet(a, 'analysis.funding.total', '0').replace(/[^0-9.]/g, '')) || 0;
      const fb = parseFloat(safeGet(b, 'analysis.funding.total', '0').replace(/[^0-9.]/g, '')) || 0;
      return fb - fa;
    }
    if (sortBy === 'updated') return new Date(b.updated_at || 0) - new Date(a.updated_at || 0);
    return 0;
  });

  document.getElementById('sidebar-count').textContent = list.length;

  if (!list.length) {
    listEl.innerHTML = `
      <div class="center-empty" style="padding:40px 12px">
        <div class="empty-icon-wrap">${icon('search', 28)}</div>
        <h3>Không tìm thấy</h3>
        <p style="font-size:12px">Thử điều chỉnh bộ lọc</p>
      </div>`;
    return;
  }

  listEl.innerHTML = list.map(p => sidebarItemHTML(p)).join('');
}

function sidebarItemHTML(p) {
  const activeClass = p.id === selectedProjectId ? 'active' : '';
  const logoUrl = p.logo || getLogoUrlFromX(p.links?.x);
  const eventCls = EVENT_CLASS[p.event] || 'active';
  const eventLbl = EVENT_LABEL[p.event] || p.event;
  const score = safeGet(p, 'analysis.score', null);
  const progress = safeGet(p, 'analysis.roadmap.progress', 0);

  return `
    <div class="sp-card ${activeClass}" data-id="${esc(p.id)}" onclick="selectProject('${esc(p.id)}')">
      <img class="sp-logo" src="${esc(logoUrl || '')}" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
      <div class="sp-logo" style="display:none;align-items:center;justify-content:center;font-size:16px;font-weight:800;color:#fff;background:${fallbackColor(p.name)};width:40px;height:40px;border-radius:10px;flex-shrink:0;margin-left:-52px;margin-right:12px">${esc((p.name || '?').charAt(0).toUpperCase())}</div>
      <div class="sp-info">
        <div class="sp-row1">
          <span class="sp-name">${esc(p.name)}</span>
          <span class="sp-event ${eventCls}">${esc(eventLbl)}</span>
          ${score !== null ? `<span class="sp-score">${score}</span>` : ''}
        </div>
        <div class="sp-progress-wrap"><div class="sp-progress" style="width:${progress}%"></div></div>
        <div class="sp-footer">
          <span style="font-size:13px;font-weight:700;color:var(--txt3)">${progress}%</span>
          <button class="sp-fav ${p.favorite ? 'on' : ''}" onclick="event.stopPropagation()" title="Read only">${icon('star', 15)}</button>
        </div>
      </div>
    </div>`;
}

function selectProject(id) {
  selectedProjectId = id;
  renderSidebar();
  renderDashboard(id);
}

function toggleFilterPanel() {
  const el = document.getElementById('filter-panel');
  const btn = document.getElementById('filter-toggle-btn');
  const open = el.style.display === 'none';
  el.style.display = open ? 'block' : 'none';
  btn.classList.toggle('active', open);
}

function showSidebarSkeleton() {
  const el = document.getElementById('project-list');
  let html = '';
  for (let i = 0; i < 6; i++) {
    html += `
      <div class="sp-card" style="pointer-events:none">
        <div class="sp-logo skeleton" style="border:none"></div>
        <div class="sp-info" style="flex:1">
          <div class="skeleton" style="height:14px;width:60%;margin-bottom:8px"></div>
          <div class="skeleton" style="height:10px;width:40%;margin-bottom:8px"></div>
          <div class="skeleton" style="height:6px;width:100%;margin-bottom:6px;border-radius:999px"></div>
          <div class="skeleton" style="height:10px;width:30%"></div>
        </div>
      </div>`;
  }
  el.innerHTML = html;
}
