// ============================================================
// theme.js — Light / Dark mode module
// ------------------------------------------------------------
// - initTheme()    : chạy khi trang load, áp dụng theme đã lưu
// - loadTheme()     : đọc theme từ localStorage (ưu tiên), nếu
//                     chưa có thì dùng prefers-color-scheme
// - applyTheme(t)   : gán data-theme lên <html> + cập nhật UI
// - saveTheme(t)    : lưu lựa chọn vào localStorage
// - toggleTheme()   : đảo Light <-> Dark, không reload trang
//
// Lưu ý: index.html đã có 1 inline script nhỏ trong <head> chạy
// TRƯỚC file này để set data-theme sớm nhất có thể (chống nháy
// màu / FOUC). File này chịu trách nhiệm đồng bộ lại UI (icon,
// label, checkbox trong Settings) và xử lý sự kiện toggle.
// ============================================================

const THEME_STORAGE_KEY = 'theme';

/**
 * Đọc theme đã lưu trong localStorage. Nếu chưa có / giá trị lỗi,
 * fallback sang theme hệ điều hành qua prefers-color-scheme.
 * @returns {'light'|'dark'}
 */
function loadTheme() {
  try {
    const saved = localStorage.getItem(THEME_STORAGE_KEY);
    if (saved === 'light' || saved === 'dark') return saved;
  } catch (e) {
    // localStorage có thể bị chặn (chế độ ẩn danh nghiêm ngặt, v.v.) — bỏ qua, dùng fallback
    console.warn('Không đọc được localStorage cho theme, dùng theme hệ điều hành:', e);
  }
  try {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
  } catch (e) {
    // ignore
  }
  return 'light';
}

/**
 * Lưu theme vào localStorage. Không throw nếu localStorage không khả dụng.
 * @param {'light'|'dark'} theme
 */
function saveTheme(theme) {
  try {
    localStorage.setItem(THEME_STORAGE_KEY, theme);
  } catch (e) {
    console.warn('Không lưu được theme vào localStorage:', e);
  }
}

/**
 * Áp dụng theme lên toàn bộ trang (CSS variables ở style.css sẽ tự
 * đổi màu cho card / sidebar / input / button / modal / scrollbar
 * thông qua selector [data-theme="dark"]) + đồng bộ icon & label.
 * @param {'light'|'dark'} theme
 */
function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);

  const sunIcon = document.getElementById('theme-icon-sun');
  const moonIcon = document.getElementById('theme-icon-moon');
  const label = document.getElementById('theme-toggle-label');
  const checkbox = document.getElementById('settings-theme-checkbox');
  const toggleBtn = document.getElementById('theme-toggle-btn');

  const isDark = theme === 'dark';

  if (sunIcon) sunIcon.style.display = isDark ? 'none' : '';
  if (moonIcon) moonIcon.style.display = isDark ? '' : 'none';
  // Label hiển thị hành động sẽ xảy ra khi bấm (giống nhiều app: hiện "Dark" ở chế độ Light, và ngược lại)
  if (label) label.textContent = isDark ? 'Light' : 'Dark';
  if (toggleBtn) toggleBtn.setAttribute('aria-pressed', String(isDark));
  if (checkbox) checkbox.checked = isDark;
}

/**
 * Đảo theme hiện tại (Light <-> Dark), lưu lại và áp dụng ngay,
 * không cần reload trang.
 */
function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  saveTheme(next);
}

/**
 * Khởi tạo theme khi app2 load xong DOM. Vì <head> đã set data-theme
 * sớm để chống nháy, ở đây ta chỉ cần đồng bộ lại icon/label/checkbox
 * theo đúng giá trị đã set (đề phòng trường hợp DOM lúc <head> chạy
 * script chưa có các phần tử header/settings).
 */
function initTheme() {
  const theme = loadTheme();
  applyTheme(theme);

  // Nếu người dùng chưa từng chọn thủ công (chưa có key trong localStorage),
  // tự cập nhật theo theme hệ điều hành khi user đổi setting OS trong lúc app đang mở.
  try {
    const media = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)');
    if (media && media.addEventListener) {
      media.addEventListener('change', (e) => {
        let hasManualChoice = false;
        try { hasManualChoice = localStorage.getItem(THEME_STORAGE_KEY) !== null; } catch (err) {}
        if (!hasManualChoice) {
          applyTheme(e.matches ? 'dark' : 'light');
        }
      });
    }
  } catch (e) {
    // trình duyệt cũ không hỗ trợ matchMedia/addEventListener — bỏ qua, không crash
  }
}

// DOM đã sẵn sàng vì các <script> nằm cuối <body>, nhưng vẫn bọc an toàn
// phòng trường hợp file này được include ở vị trí khác trong tương lai.
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initTheme);
} else {
  initTheme();
}
