/**
 * utils.js
 * Helpers — format, escape, generate UID, deep get, v.v.
 */
function esc(s) {
  return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function getLogoUrlFromX(x) {
  if (!x) return '';
  const m = x.match(/x\.com\/([^/?]+)/i) || x.match(/twitter\.com\/([^/?]+)/i);
  if (!m) return '';
  return `https://unavatar.io/twitter/${m[1].replace('@', '')}`;
}

function fallbackColor(name) {
  const colors = ['#f97316', '#ef4444', '#16a34a', '#0ea5e9', '#8b5cf6', '#eab308', '#14b8a6', '#64748b'];
  let h = 0;
  for (let i = 0; i < (name || '').length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return colors[h % colors.length];
}

function formatRelative(iso) {
  if (!iso) return '—';
  const d = new Date(iso), n = new Date();
  const d0 = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const n0 = new Date(n.getFullYear(), n.getMonth(), n.getDate());
  const diff = Math.round((n0 - d0) / 86400000);
  if (diff <= 0) return 'Hôm nay';
  if (diff === 1) return 'Hôm qua';
  if (diff < 30) return diff + ' ngày trước';
  return d.toLocaleDateString('vi-VN');
}

function formatTimeAgo(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  const diffSec = Math.round((Date.now() - d.getTime()) / 1000);
  if (diffSec < 60) return 'Vừa xong';
  if (diffSec < 3600) return Math.floor(diffSec / 60) + ' phút trước';
  if (diffSec < 86400) return Math.floor(diffSec / 3600) + ' giờ trước';
  return formatRelative(iso);
}

function safeGet(obj, path, fallback) {
  return path.split('.').reduce((o, k) => (o && o[k] !== undefined) ? o[k] : undefined, obj) ?? fallback;
}

function deepMerge(target, source) {
  for (const key in source) {
    if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
      target[key] = target[key] || {};
      deepMerge(target[key], source[key]);
    } else {
      target[key] = source[key];
    }
  }
  return target;
}

/** Set giá trị vào object theo đường dẫn dạng "a.b.c", tự tạo object con nếu chưa có. */
function setPath(obj, path, value) {
  const keys = path.split('.');
  let cur = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i];
    if (!cur[k] || typeof cur[k] !== 'object' || Array.isArray(cur[k])) cur[k] = {};
    cur = cur[k];
  }
  cur[keys[keys.length - 1]] = value;
  return obj;
}

/** Sinh id ngắn dùng cho milestone / event tạo thủ công phía client. */
function genLocalId() {
  return 'l' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function generatePromptText(mode, source, categories) {
  const catStr = categories.join(', ');
  const depth = mode === 'deep' ? 'kỹ lưỡng trong 10 ngày gần nhất' : 'tổng quan';
  const srcStr = source === 'x' ? 'chỉ X (Twitter)' : 'Multi nguồn (Discord, Galxe, Medium, Reddit, Twitter, v.v.)';

  return `Bạn là một chuyên gia phân tích Crypto Airdrop.

Hãy thực hiện check news ${depth} cho các dự án thuộc danh mục: ${catStr}.

Nguồn dữ liệu: ${srcStr}.

Vai trò: Chỉ lấy thông tin chính xác từ nguồn chính thức (X/Twitter hoặc Website của đúng dự án được liệt kê bên dưới), tuyệt đối không bịa tin, không suy đoán nếu không có dữ liệu thật.

Yêu cầu output JSON với cấu trúc sau cho mỗi dự án:
{
  "project_name": "Tên dự án",
  "category": "DePIN / Testnet",
  "event": "ACTIVE / SNAPSHOT / TGE_SOON / CLAIM_LIVE / ENDED",
  "analysis": {
    "score": <number 0-100>,
    "info": { "description": "...", "chain": "...", "type": "..." },
    "funding": { "total": "$X", "round": "Seed" },
    "backers": ["Backer 1", "Backer 2"],
    "roadmap": { "progress": <percent>, "milestones": "X / Y" },
    "tokenomics": { "tge": "Q4 2026", "utility": "..." },
    "community": { "score": <number>, "followers": "...", "discord": "..." },
    "development": { "score": <number>, "status": "..." },
    "news": [{"title": "...", "date": "..."}],
    "ai_analysis": { "overall": "...", "summary": "..." },
    "notes": "..."
  }
}

Lưu ý:
- Chỉ trả về JSON hợp lệ, không thêm Markdown.
- Chỉ lấy thông tin chính xác từ nguồn chính thức, không được bịa tin.`;
}
