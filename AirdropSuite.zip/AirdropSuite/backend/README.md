# Airdrop Suite — Backend Control Center

Backend dùng chung cho App 1 (List Airdrop) và App 2 (Check Airdrop).
Đây là **Single Source of Truth** duy nhất cho toàn bộ dữ liệu — App 1 và
App 2 không truy cập SQLite hoặc file JSON trực tiếp, mọi thao tác đọc/ghi
đều đi qua REST API bên dưới.

## Tech Stack

- Python 3
- FastAPI
- SQLite + SQLAlchemy
- Pydantic
- Jinja2 + Vanilla JS

## Cấu trúc

```
backend/
├── main.py          # FastAPI app, routes, mount App1/App2/static
├── config.py         # BASE_DIR, DATABASE_URL
├── database.py        # SQLAlchemy engine/session
├── models.py          # Project, ActivityLog, Setting (ORM)
├── schemas.py          # Pydantic request/response models
├── crud.py            # Create/Read/Update/Delete cơ bản
├── storage.py          # Import/Export/Stats/Backup/Settings (tầng cao hơn)
├── utils.py            # normalize_project, parse_datetime, generate_uid
├── static/            # JS/CSS cho trang Dashboard riêng của Backend (tại "/")
├── templates/          # index.html của Dashboard (Jinja2)
├── logs/              # Backup .db, log file
└── uploads/            # (dự phòng) file upload nếu cần trong tương lai
```

## Chạy độc lập (development)

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Truy cập:
- Dashboard: http://127.0.0.1:8000/
- App 1: http://127.0.0.1:8000/app1/
- App 2: http://127.0.0.1:8000/app2/
- Swagger API docs: http://127.0.0.1:8000/docs

> Lưu ý: khi chạy độc lập như trên, `main.py` tự tìm 2 thư mục `../app1` và
> `../app2` (nằm cùng cấp với `backend/`) để mount vào `/app1` và `/app2`.
> Nếu không tồn tại, Backend vẫn chạy bình thường — chỉ là 2 route đó sẽ
> không khả dụng.

Khi dùng cho cả bộ 3 thành phần (Backend + App 1 + App 2 + cửa sổ chọn app),
hãy chạy `python launcher.py` ở thư mục gốc dự án thay vì chạy `uvicorn`
trực tiếp ở đây.

## API chính

Xem đầy đủ & thử trực tiếp tại `/docs` (Swagger UI) khi server đang chạy.
Tóm tắt: `GET/POST/PUT/PATCH/DELETE /api/project(s)`, `/api/import`,
`/api/export`, `/api/stats`, `/api/activity`, `/api/settings`, `/api/backup`,
`/api/logs`, `/api/health`.
