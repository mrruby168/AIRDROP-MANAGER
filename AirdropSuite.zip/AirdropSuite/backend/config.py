"""
backend/config.py
------------------
Cấu hình đường dẫn cho toàn bộ backend.

Phân biệt rõ 2 loại thư mục (yêu cầu #6/#7/#8: resource_path(), không
hardcode ổ đĩa, tự tạo thư mục data khi chạy lần đầu, không crash khi
đóng gói .exe ONEDIR):

  * RESOURCE (đọc-only): mã nguồn + template/static được bundle cùng .exe
    (PyInstaller --add-data). Dùng resource_path().
  * DATA (ghi được): database.db, logs/, uploads/, config JSON... Phải
    nằm NGOÀI bundle vì thư mục cài đặt (vd Program Files) có thể không
    có quyền ghi, và để không bị mất dữ liệu khi cập nhật/ghi đè bản
    build mới. Dùng get_data_dir().
"""

import os
import sys


def resource_path(*parts: str) -> str:
    """Trả về đường dẫn tuyệt đối tới 1 resource (đọc-only) được bundle
    cùng backend/. Hoạt động đúng cả khi chạy `python main.py` lẫn khi
    đã đóng gói PyInstaller (ONEDIR/ONEFILE)."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        base = os.path.join(sys._MEIPASS, "backend")
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, *parts)


def get_data_dir() -> str:
    """Trả về thư mục GHI ĐƯỢC để lưu database/log/upload/config của
    người dùng, tách biệt khỏi bundle .exe. Không hardcode ổ đĩa:
      - Dev mode (`python launcher.py`): dùng ngay backend/ như trước
        (giữ nguyên hành vi cũ, không phá vỡ workflow phát triển).
      - Đóng gói .exe: dùng %LOCALAPPDATA%/AirdropSuite trên Windows
        (hoặc thư mục home trên macOS/Linux) — luôn có quyền ghi bất kể
        app được cài ở Program Files hay ổ đĩa nào.
    Tự tạo thư mục nếu chưa tồn tại; không bao giờ raise ra ngoài (nếu
    có lỗi bất ngờ, fallback về thư mục home của user).
    """
    try:
        if getattr(sys, "frozen", False):
            base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
            data_dir = os.path.join(base, "AirdropSuite")
        else:
            data_dir = os.path.dirname(os.path.abspath(__file__))
        os.makedirs(data_dir, exist_ok=True)
        return data_dir
    except Exception as e:
        print(f"[Config] Cảnh báo: không tạo được data dir mặc định ({e}), dùng thư mục home.")
        fallback = os.path.join(os.path.expanduser("~"), "AirdropSuite")
        os.makedirs(fallback, exist_ok=True)
        return fallback


# BASE_DIR giữ lại để tương thích ngược với code cũ (đọc-only resource dir).
BASE_DIR = resource_path()

# DATA_DIR: nơi thực sự lưu database.db, logs/, uploads/ — luôn ghi được.
DATA_DIR = get_data_dir()
LOGS_DIR = os.path.join(DATA_DIR, "logs")
UPLOADS_DIR = os.path.join(DATA_DIR, "uploads")
CONFIG_DIR = os.path.join(DATA_DIR, "config")

for _d in (DATA_DIR, LOGS_DIR, UPLOADS_DIR, CONFIG_DIR):
    try:
        os.makedirs(_d, exist_ok=True)
    except Exception as e:
        print(f"[Config] Cảnh báo: không tạo được thư mục {_d}: {e}")

DATABASE_URL = f"sqlite:///{os.path.join(DATA_DIR, 'database.db')}"
