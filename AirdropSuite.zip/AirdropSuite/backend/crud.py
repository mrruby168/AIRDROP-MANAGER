from typing import Optional, List
from datetime import datetime
from sqlalchemy.orm import Session
from models import Project, ActivityLog
from utils import normalize_project


def log_activity(db: Session, action: str, detail: str = ""):
    """Ghi log hoạt động vào DB."""
    log = ActivityLog(action=action, detail=detail)
    db.add(log)
    db.commit()


def get_project(db: Session, project_id: str) -> Optional[Project]:
    return db.query(Project).filter(Project.id == project_id).first()


def get_projects(db: Session, skip: int = 0, limit: int = 2000) -> List[Project]:
    return db.query(Project).offset(skip).limit(limit).all()


def create_project(db: Session, data: dict) -> Project:
    normalized = normalize_project(data)
    project = Project(**normalized)
    db.add(project)
    db.commit()
    db.refresh(project)
    log_activity(db, "Project Created", f"Project '{project.name}' created")
    return project


def update_project(db: Session, project_id: str, data: dict) -> Optional[Project]:
    project = get_project(db, project_id)
    if not project:
        return None

    # Merge dữ liệu cũ + mới rồi normalize để đảm bảo đủ field
    merged = {**project.__dict__, **data}
    merged.pop("_sa_instance_state", None)
    merged["id"] = project_id
    merged["created_at"] = project.created_at          # không đổi ngày tạo
    merged["updated_at"] = datetime.utcnow()            # luôn cập nhật thời gian sửa

    normalized = normalize_project(merged)
    normalized.pop("id", None)  # Không đổi PK

    for key, value in normalized.items():
        if hasattr(project, key):
            setattr(project, key, value)

    db.commit()
    db.refresh(project)
    log_activity(db, "Project Updated", f"Project '{project.name}' updated")
    return project


def delete_project(db: Session, project_id: str) -> bool:
    project = get_project(db, project_id)
    if not project:
        return False
    name = project.name
    db.delete(project)
    db.commit()
    log_activity(db, "Project Deleted", f"Project '{name}' deleted")
    return True


def bulk_replace_projects(db: Session, projects: List[dict]) -> int:
    """Ghi đè toàn bộ projects. Dùng cho PUT /api/projects."""
    db.query(Project).delete()
    db.commit()

    count = 0
    for p in projects:
        normalized = normalize_project(p)
        db.add(Project(**normalized))
        count += 1

    db.commit()
    log_activity(db, "Bulk Replace", f"Replaced with {count} projects")
    return count
