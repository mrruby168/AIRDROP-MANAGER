"""
main.py
-------
FastAPI application — Backend Control Center cho Airdrop Suite.
Single Source of Truth cho App 1 (List Airdrop) và App 2 (Check Airdrop).
"""

import os
from datetime import datetime
from typing import List
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from config import BASE_DIR
from database import get_db, engine, Base
from schemas import (
    ProjectCreate, ProjectUpdate, ProjectOut,
    ProjectsBulk, ImportOut, ExportOut, HealthOut
)
from crud import (
    get_project, get_projects, create_project, update_project,
    delete_project, bulk_replace_projects, log_activity
)
from storage import Storage, LOGS_DIR

# --------------------------------------------------------------------- #
# Auto migration — tự tạo bảng nếu thiếu khi khởi động
# --------------------------------------------------------------------- #
try:
    Base.metadata.create_all(bind=engine)
except Exception as e:
    # Không để lỗi khởi tạo DB (vd thư mục data không ghi được) làm crash
    # toàn bộ process trước khi kịp in log rõ ràng cho người dùng.
    print(f"[Backend] LỖI khởi tạo database: {e}")
    raise

app = FastAPI(
    title="Airdrop Suite",
    description="Backend Control Center — Shared backend for App 1 & App 2",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files & Templates (Backend Control Center UI)
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

# --------------------------------------------------------------------- #
# App 1 & App 2 — phục vụ trực tiếp từ Backend (single process, single port)
# PROJECT_ROOT = thư mục cha của backend/ (Project/app1, Project/app2)
# --------------------------------------------------------------------- #
PROJECT_ROOT = os.path.dirname(BASE_DIR)
APP1_DIR = os.path.join(PROJECT_ROOT, "app1")
APP2_DIR = os.path.join(PROJECT_ROOT, "app2")

if os.path.isdir(APP1_DIR):
    app.mount("/app1", StaticFiles(directory=APP1_DIR, html=True), name="app1")
if os.path.isdir(APP2_DIR):
    app.mount("/app2", StaticFiles(directory=APP2_DIR, html=True), name="app2")

# --------------------------------------------------------------------- #
# Startup log
# --------------------------------------------------------------------- #
@app.on_event("startup")
def on_startup():
    db = Session(bind=engine)
    try:
        log_activity(db, "Server Started", "FastAPI server is running on http://127.0.0.1:8000")
    finally:
        db.close()

# --------------------------------------------------------------------- #
# Exception handlers — Không leak traceback ra client
# --------------------------------------------------------------------- #
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail}
    )

@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"}
    )

# --------------------------------------------------------------------- #
# Health
# --------------------------------------------------------------------- #
@app.get("/api/health", response_model=HealthOut)
def health():
    return {"status": "ok", "version": "1.0.0"}

# --------------------------------------------------------------------- #
# Dashboard UI
# --------------------------------------------------------------------- #
@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# --------------------------------------------------------------------- #
# REST API — Projects (App 1 compatible)
# --------------------------------------------------------------------- #
@app.get("/api/projects", response_model=List[ProjectOut])
def api_list_projects(db: Session = Depends(get_db)):
    """Trả toàn bộ projects — dùng cho App 1 load."""
    return get_projects(db)


@app.put("/api/projects")
def api_bulk_replace(data: ProjectsBulk, db: Session = Depends(get_db)):
    """
    Ghi đè toàn bộ projects.
    App 1 dùng khi save từ localStorage lên Backend.
    """
    count = bulk_replace_projects(db, [p.dict() for p in data.projects])
    return {"ok": True, "count": count}


@app.get("/api/project/{project_id}", response_model=ProjectOut)
def api_get_project(project_id: str, db: Session = Depends(get_db)):
    p = get_project(db, project_id)
    if not p:
        raise HTTPException(status_code=404, detail="Project not found")
    return p


@app.post("/api/project", response_model=ProjectOut)
def api_create_project(data: ProjectCreate, db: Session = Depends(get_db)):
    if data.id and get_project(db, data.id):
        raise HTTPException(status_code=400, detail="Project ID already exists")
    return create_project(db, data.dict())


@app.put("/api/project/{project_id}", response_model=ProjectOut)
def api_update_project(project_id: str, data: ProjectUpdate, db: Session = Depends(get_db)):
    p = update_project(db, project_id, data.dict(exclude_unset=True))
    if not p:
        raise HTTPException(status_code=404, detail="Project not found")
    return p


@app.patch("/api/project/{project_id}", response_model=ProjectOut)
def api_patch_project(project_id: str, data: ProjectUpdate, db: Session = Depends(get_db)):
    """Alias của PUT — cập nhật một phần field (partial update)."""
    p = update_project(db, project_id, data.dict(exclude_unset=True))
    if not p:
        raise HTTPException(status_code=404, detail="Project not found")
    return p


@app.delete("/api/project/{project_id}")
def api_delete_project(project_id: str, db: Session = Depends(get_db)):
    ok = delete_project(db, project_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"ok": True}

# --------------------------------------------------------------------- #
# Import / Export
# --------------------------------------------------------------------- #
@app.post("/api/import", response_model=ImportOut)
def api_import_projects(data: ProjectsBulk, db: Session = Depends(get_db)):
    """
    Import JSON từ App 1 / App 2.
    Normalize + merge (update by ID, create nếu chưa có).
    Trả kèm danh sách project đã lưu để client đồng bộ ngay.
    """
    count, affected = Storage.import_projects(db, [p.dict() for p in data.projects])
    return {"imported": count, "ok": True, "projects": affected}


@app.get("/api/export", response_model=ExportOut)
def api_export_projects(db: Session = Depends(get_db)):
    """Export JSON format giống App 1."""
    projects = Storage.export_projects(db)
    return {
        "projects": projects,
        "exported_at": datetime.utcnow().isoformat()
    }

# --------------------------------------------------------------------- #
# Stats & Activity
# --------------------------------------------------------------------- #
@app.get("/api/stats")
def api_stats(db: Session = Depends(get_db)):
    return Storage.get_stats(db)


@app.get("/api/activity")
def api_activity(limit: int = 20, db: Session = Depends(get_db)):
    logs = Storage.get_recent_activity(db, limit)
    return [
        {
            "id": l.id,
            "action": l.action,
            "detail": l.detail,
            "created_at": l.created_at.isoformat(),
        }
        for l in logs
    ]

# --------------------------------------------------------------------- #
# Backup
# --------------------------------------------------------------------- #
@app.post("/api/backup")
def api_backup(db: Session = Depends(get_db)):
    path = Storage.backup_database(db)
    return {"backup_path": path, "ok": True}


@app.get("/api/logs")
def api_list_log_files():
    try:
        files = [
            f for f in os.listdir(LOGS_DIR)
            if f.endswith(".db") or f.endswith(".json") or f.endswith(".log")
        ]
    except OSError as e:
        print(f"[Backend] Cảnh báo: không đọc được LOGS_DIR ({e})")
        files = []
    return {"files": sorted(files, reverse=True)}

# --------------------------------------------------------------------- #
# Settings
# --------------------------------------------------------------------- #
@app.get("/api/settings")
def api_get_settings(db: Session = Depends(get_db)):
    return Storage.get_settings(db)


@app.put("/api/settings")
def api_update_settings(data: dict, db: Session = Depends(get_db)):
    for k, v in data.items():
        Storage.update_setting(db, k, str(v))
    return {"ok": True}