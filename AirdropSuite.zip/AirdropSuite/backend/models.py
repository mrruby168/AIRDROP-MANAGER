from sqlalchemy import Column, String, Boolean, DateTime, JSON, Integer
from database import Base
from datetime import datetime


class Project(Base):
    __tablename__ = "projects"

    id         = Column(String, primary_key=True, index=True)
    category   = Column(String, default="TESTNET", nullable=False)
    name       = Column(String, nullable=False)
    logo       = Column(String, default="")
    links      = Column(JSON, default=dict)
    tasks      = Column(JSON, default=list)
    favorite   = Column(Boolean, default=False)
    event      = Column(String, default="ACTIVE")
    analysis   = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class ActivityLog(Base):
    __tablename__ = "activity_logs"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    action     = Column(String, nullable=False)
    detail     = Column(String, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class Setting(Base):
    __tablename__ = "settings"

    id    = Column(Integer, primary_key=True, autoincrement=True)
    key   = Column(String, unique=True, nullable=False)
    value = Column(String, default="")
