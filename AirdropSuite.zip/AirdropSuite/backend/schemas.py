from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


class LinkOther(BaseModel):
    label: str = ""
    url: str = ""


class Links(BaseModel):
    website: str = ""
    x: str = ""
    discord: str = ""
    guild: str = ""
    galxe: str = ""
    docs: str = ""
    other: List[LinkOther] = Field(default_factory=list)


class Task(BaseModel):
    id: str
    text: str = ""
    done: bool = False
    doneAt: Optional[str] = None


class Analysis(BaseModel):
    score: Optional[Any] = None
    last_update: Optional[str] = None
    info: Dict[str, Any] = Field(default_factory=dict)
    funding: Dict[str, Any] = Field(default_factory=dict)
    backers: List[Any] = Field(default_factory=list)
    roadmap: Dict[str, Any] = Field(default_factory=dict)
    tokenomics: Optional[Any] = None
    community: Dict[str, Any] = Field(default_factory=dict)
    development: Dict[str, Any] = Field(default_factory=dict)
    news: List[Any] = Field(default_factory=list)
    ai_analysis: Dict[str, Any] = Field(default_factory=dict)
    notes: str = ""


class ProjectBase(BaseModel):
    id: Optional[str] = None
    category: str = "TESTNET"
    name: str = ""
    logo: str = ""
    links: Links = Field(default_factory=Links)
    tasks: List[Task] = Field(default_factory=list)
    favorite: bool = False
    event: str = "ACTIVE"
    analysis: Analysis = Field(default_factory=Analysis)


class ProjectCreate(ProjectBase):
    pass


class ProjectUpdate(BaseModel):
    category: Optional[str] = None
    name: Optional[str] = None
    logo: Optional[str] = None
    links: Optional[Links] = None
    tasks: Optional[List[Task]] = None
    favorite: Optional[bool] = None
    event: Optional[str] = None
    analysis: Optional[Analysis] = None


class ProjectOut(ProjectBase):
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class ProjectsBulk(BaseModel):
    projects: List[ProjectBase] = Field(default_factory=list)


class ImportOut(BaseModel):
    imported: int
    ok: bool = True
    projects: List[ProjectOut] = Field(default_factory=list)


class ExportOut(BaseModel):
    projects: List[ProjectOut]
    exported_at: str


class HealthOut(BaseModel):
    status: str
    version: str
