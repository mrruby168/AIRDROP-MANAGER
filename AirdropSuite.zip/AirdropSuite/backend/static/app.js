/**
 * app.js
 * ------
 * Dashboard controller cho Airdrop Suite Backend.
 * Gọi API, render stats, activity, projects, xử lý Import/Export/Backup.
 */

const API_BASE = "";

async function fetchJSON(url, opts = {}) {
  const res = await fetch(url, opts);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || res.statusText);
  }
  return res.json();
}

function showToast(msg, type = "ok") {
  const t = document.getElementById("toast");
  document.getElementById("toast-msg").textContent = msg;
  const dot = document.getElementById("toast-dot");
  dot.className = "toast-dot " + type;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 3000);
}

function esc(s) {
  return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/* ------------------------------------------------------------------ */
/* Navigation
/* ------------------------------------------------------------------ */
function setNav(id) {
  document.querySelectorAll(".nav-item").forEach(n =>
    n.classList.toggle("active", n.dataset.page === id)
  );
  document.querySelectorAll(".page").forEach(p =>
    p.classList.toggle("hidden", p.id !== "page-" + id)
  );
  if (id === "dashboard") loadDashboard();
  if (id === "projects") loadProjects();
  if (id === "logs") loadLogs();
  if (id === "backup") loadBackups();
}

/* ------------------------------------------------------------------ */
/* Dashboard
/* ------------------------------------------------------------------ */
async function loadDashboard() {
  try {
    const stats = await fetchJSON("/api/stats");
    document.getElementById("stat-total").textContent = stats.total_projects;
    document.getElementById("stat-testnet").textContent = stats.testnet_projects;
    document.getElementById("stat-depin").textContent = stats.depin_projects;
    document.getElementById("stat-tasks").textContent = stats.total_tasks.toLocaleString();
    document.getElementById("stat-completed").textContent = stats.completed_tasks.toLocaleString();
    document.getElementById("stat-fav").textContent = stats.favorite_projects;

    const logs = await fetchJSON("/api/activity?limit=20");
    document.getElementById("activity-list").innerHTML = logs.map(renderActivityItem).join("");
  } catch (e) {
    console.error(e);
    showToast("Failed to load dashboard", "err");
  }
}

function renderActivityItem(l) {
  const icons = {
    "Server Started": "🟢", "Project Created": "📁", "Project Updated": "✏️",
    "Project Deleted": "🗑", "Import": "⬇️", "Export": "⬆️", "Backup": "💾"
  };
  const colors = {
    "Server Started": "green", "Project Created": "blue", "Project Updated": "purple",
    "Project Deleted": "red", "Import": "blue", "Export": "orange", "Backup": "green"
  };
  const time = new Date(l.created_at).toLocaleString("vi-VN");
  return `
    <div class="activity-item">
      <div class="act-icon ${colors[l.action] || 'blue'}">${icons[l.action] || '🔹'}</div>
      <div class="act-body">
        <div class="act-title">${esc(l.action)}</div>
        <div class="act-detail">${esc(l.detail)}</div>
      </div>
      <div class="act-time">${time}</div>
    </div>`;
}

/* ------------------------------------------------------------------ */
/* Projects Page
/* ------------------------------------------------------------------ */
async function loadProjects() {
  try {
    const projects = await fetchJSON("/api/projects");
    const tbody = document.getElementById("projects-tbody");
    tbody.innerHTML = projects.map(p => `
      <tr>
        <td>${esc(p.name)}</td>
        <td><span class="badge">${esc(p.category)}</span></td>
        <td>${esc(p.event)}</td>
        <td>${Array.isArray(p.tasks) ? p.tasks.length : 0}</td>
        <td>${p.favorite ? '★' : '☆'}</td>
      </tr>
    `).join("");
  } catch (e) {
    console.error(e);
  }
}

/* ------------------------------------------------------------------ */
/* Logs Page
/* ------------------------------------------------------------------ */
async function loadLogs() {
  try {
    const logs = await fetchJSON("/api/activity?limit=50");
    document.getElementById("logs-list").innerHTML = logs.map(renderActivityItem).join("");
  } catch (e) {
    console.error(e);
  }
}

/* ------------------------------------------------------------------ */
/* Backup Page
/* ------------------------------------------------------------------ */
async function loadBackups() {
  try {
    const data = await fetchJSON("/api/logs");
    const list = document.getElementById("backup-list");
    const files = data.files.filter(f => f.endsWith(".db"));
    list.innerHTML = files.length
      ? files.map(f => `<div class="activity-item"><div class="act-body"><div class="act-title">${esc(f)}</div></div></div>`).join("")
      : '<div style="color:var(--text3);font-size:12px">No backups yet.</div>';
  } catch (e) {
    console.error(e);
  }
}

/* ------------------------------------------------------------------ */
/* Tools
/* ------------------------------------------------------------------ */
function openSwagger() {
  window.open("/docs", "_blank");
}

function openLogsFolder() {
  window.open("/api/logs", "_blank");
}

async function exportJSON() {
  try {
    const data = await fetchJSON("/api/export");
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `airdrop-suite-export-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    showToast("Exported successfully", "ok");
    loadDashboard();
  } catch (e) {
    showToast("Export failed: " + e.message, "err");
  }
}

function importJSON() {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = ".json";
  input.onchange = () => {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        const projects = Array.isArray(parsed) ? parsed : parsed.projects;
        if (!Array.isArray(projects)) throw new Error("File JSON không hợp lệ: thiếu mảng \"projects\"");
        const data = await fetchJSON("/api/import", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ projects })
        });
        showToast(`Imported ${data.imported} projects`, "ok");
        loadDashboard();
      } catch (e) {
        showToast("Import failed: " + e.message, "err");
      }
    };
    reader.readAsText(file);
  };
  input.click();
}

async function backupDB() {
  try {
    const data = await fetchJSON("/api/backup", { method: "POST" });
    showToast("Backup created: " + data.backup_path.split("/").pop(), "ok");
    loadDashboard();
    if (!document.getElementById("page-backup").classList.contains("hidden")) loadBackups();
  } catch (e) {
    showToast("Backup failed: " + e.message, "err");
  }
}

/* ------------------------------------------------------------------ */
/* Init
/* ------------------------------------------------------------------ */
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".nav-item").forEach(btn => {
    btn.addEventListener("click", () => setNav(btn.dataset.page));
  });

  document.getElementById("menu-toggle").addEventListener("click", () => {
    document.getElementById("sidebar").classList.toggle("open");
  });

  setNav("dashboard");
});