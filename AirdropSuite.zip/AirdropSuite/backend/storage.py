import os
import shutil
from datetime import datetime
from typing import List
from sqlalchemy.orm import Session

from models import Project, ActivityLog, Setting
from crud import get_projects, log_activity
from utils import normalize_project
from config import LOGS_DIR, UPLOADS_DIR, DATA_DIR

# LOGS_DIR / UPLOADS_DIR đã được tạo sẵn (exist_ok=True) trong config.py
# khi module được import lần đầu — không cần makedirs lại ở đây.


class Storage:
    """Tầng truy cập dữ liệu cao cấp — dùng chung cho App 1 & App 2."""

    @staticmethod
    def import_projects(db: Session, projects_data: List[dict]):
        """
        Import / Merge projects từ JSON.
        Update nếu đã tồn tại (theo ID), tạo mới nếu chưa có.
        Trả về (count, affected_projects) để API trả kèm dữ liệu đã lưu
        cho App 1 / App 2 đồng bộ ngay, không cần gọi lại GET riêng.
        """
        count = 0
        affected: List[Project] = []
        for item in projects_data:
            pid = item.get("id")
            existing = db.query(Project).filter(Project.id == pid).first() if pid else None

            normalized = normalize_project(item)

            if existing:
                # Giữ nguyên created_at gốc trừ khi JSON import chỉ định rõ ràng
                if not item.get("created_at"):
                    normalized["created_at"] = existing.created_at
                for key, value in normalized.items():
                    if key != "id" and hasattr(existing, key):
                        setattr(existing, key, value)
                existing.updated_at = datetime.utcnow()
                affected.append(existing)
            else:
                new_project = Project(**normalized)
                db.add(new_project)
                affected.append(new_project)
            count += 1

        db.commit()
        for p in affected:
            db.refresh(p)
        log_activity(db, "Import", f"Imported {count} projects")
        return count, affected

    @staticmethod
    def export_projects(db: Session) -> List[dict]:
        """Export toàn bộ projects ra JSON format chuẩn App 1."""
        rows = get_projects(db)
        out = []
        for p in rows:
            out.append({
                "id": p.id,
                "category": p.category,
                "name": p.name,
                "logo": p.logo,
                "links": p.links,
                "tasks": p.tasks,
                "favorite": p.favorite,
                "event": p.event,
                "analysis": p.analysis,
                "created_at": p.created_at.isoformat() if p.created_at else None,
                "updated_at": p.updated_at.isoformat() if p.updated_at else None,
            })
        return out

    @staticmethod
    def get_stats(db: Session) -> dict:
        """Thống kê tổng quan cho Dashboard."""
        total = db.query(Project).count()
        testnet = db.query(Project).filter(Project.category == "TESTNET").count()
        depin = db.query(Project).filter(Project.category == "DEPIN").count()
        favorites = db.query(Project).filter(Project.favorite == True).count()

        tasks_total = 0
        tasks_done = 0
        for p in db.query(Project).all():
            if isinstance(p.tasks, list):
                tasks_total += len(p.tasks)
                tasks_done += sum(
                    1 for t in p.tasks
                    if isinstance(t, dict) and t.get("done")
                )

        return {
            "total_projects": total,
            "testnet_projects": testnet,
            "depin_projects": depin,
            "total_tasks": tasks_total,
            "completed_tasks": tasks_done,
            "favorite_projects": favorites,
        }

    @staticmethod
    def get_recent_activity(db: Session, limit: int = 20) -> List[ActivityLog]:
        return (
            db.query(ActivityLog)
            .order_by(ActivityLog.created_at.desc())
            .limit(limit)
            .all()
        )

    @staticmethod
    def backup_database(db: Session) -> str:
        """Copy SQLite file sang /logs với timestamp. Không crash nếu
        vì lý do nào đó chưa có file database.db (vd lần chạy đầu tiên
        chưa từng ghi dữ liệu) — trả về thông báo lỗi rõ ràng thay vì
        để exception rơi ra tận API caller."""
        db_path = os.path.join(DATA_DIR, "database.db")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"database_backup_{timestamp}.db"
        backup_path = os.path.join(LOGS_DIR, backup_name)
        try:
            shutil.copy2(db_path, backup_path)
        except FileNotFoundError:
            log_activity(db, "Backup", "Backup thất bại: chưa tìm thấy database.db")
            raise FileNotFoundError(f"Không tìm thấy database tại: {db_path}")
        except Exception as e:
            log_activity(db, "Backup", f"Backup thất bại: {e}")
            raise
        log_activity(db, "Backup", f"Database backed up to {backup_name}")
        return backup_path

    @staticmethod
    def get_settings(db: Session) -> dict:
        return {s.key: s.value for s in db.query(Setting).all()}

    @staticmethod
    def update_setting(db: Session, key: str, value: str):
        s = db.query(Setting).filter(Setting.key == key).first()
        if s:
            s.value = value
        else:
            s = Setting(key=key, value=value)
            db.add(s)
        db.commit()