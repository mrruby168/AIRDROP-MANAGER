import time
import random
from typing import Any, Dict
from datetime import datetime


def generate_uid() -> str:
    """Tạo ID unique tương thích với App 1."""
    return f"{int(time.time() * 1000):x}{random.randint(0x1000, 0xffff):x}"


def parse_datetime(value: Any):
    """
    Chuẩn hóa giá trị timestamp về Python `datetime` object.
    SQLite/SQLAlchemy DateTime column CHỈ chấp nhận datetime/date object,
    trong khi App 1 / App 2 / JSON import luôn gửi timestamp dạng ISO string.
    Trả về None nếu không parse được (caller sẽ tự set default).
    """
    if isinstance(value, datetime):
        return value
    if isinstance(value, str) and value.strip():
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
    return None


def normalize_project(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Chuẩn hóa project về Data Model chuẩn.
    Đảm bảo 100% tương thích với App 1 — tự thêm field thiếu,
    tự tạo analysis mặc định, tự validate event & category.
    """
    if not isinstance(data, dict):
        data = {}

    # ---- links ----
    raw_links = data.get("links") or {}
    if not isinstance(raw_links, dict):
        raw_links = {}

    other_links = []
    if isinstance(raw_links.get("other"), list):
        for o in raw_links["other"]:
            if isinstance(o, dict) and o.get("url"):
                other_links.append({
                    "label": str(o.get("label", "")),
                    "url": str(o.get("url", ""))
                })

    links = {
        "website": str(raw_links.get("website", "")),
        "x": str(raw_links.get("x", raw_links.get("twitter", ""))),
        "discord": str(raw_links.get("discord", "")),
        "guild": str(raw_links.get("guild", "")),
        "galxe": str(raw_links.get("galxe", "")),
        "docs": str(raw_links.get("docs", "")),
        "other": other_links
    }

    # ---- tasks ----
    raw_tasks = data.get("tasks")
    tasks = []
    if isinstance(raw_tasks, list):
        for t in raw_tasks:
            if isinstance(t, dict):
                tasks.append({
                    "id": str(t.get("id", generate_uid())),
                    "text": str(t.get("text", "")),
                    "done": bool(t.get("done", False)),
                    "doneAt": t.get("doneAt") if t.get("doneAt") else None
                })

    # ---- analysis ----
    raw_analysis = data.get("analysis")
    analysis = {
        "score": None,
        "last_update": None,
        "info": {},
        "funding": {},
        "backers": [],
        "roadmap": {},
        "tokenomics": None,
        "community": {},
        "development": {},
        "news": [],
        "ai_analysis": {},
        "notes": ""
    }
    if isinstance(raw_analysis, dict):
        analysis["score"] = raw_analysis.get("score")
        analysis["last_update"] = raw_analysis.get("last_update") or None
        analysis["info"] = raw_analysis.get("info") if isinstance(raw_analysis.get("info"), dict) else {}
        analysis["funding"] = raw_analysis.get("funding") if isinstance(raw_analysis.get("funding"), dict) else {}
        analysis["backers"] = raw_analysis.get("backers") if isinstance(raw_analysis.get("backers"), list) else []
        analysis["roadmap"] = raw_analysis.get("roadmap") if isinstance(raw_analysis.get("roadmap"), dict) else {}
        analysis["tokenomics"] = raw_analysis.get("tokenomics") if "tokenomics" in raw_analysis else None
        analysis["community"] = raw_analysis.get("community") if isinstance(raw_analysis.get("community"), dict) else {}
        analysis["development"] = raw_analysis.get("development") if isinstance(raw_analysis.get("development"), dict) else {}
        analysis["news"] = raw_analysis.get("news") if isinstance(raw_analysis.get("news"), list) else []
        analysis["ai_analysis"] = raw_analysis.get("ai_analysis") if isinstance(raw_analysis.get("ai_analysis"), dict) else {}
        analysis["notes"] = str(raw_analysis.get("notes", ""))

    # ---- event ----
    event = data.get("event", "ACTIVE")
    valid_events = {"ACTIVE", "SNAPSHOT", "TGE_SOON", "CLAIM_LIVE", "ENDED"}
    if event not in valid_events:
        # Legacy fallback: nếu có field tge boolean cũ
        if data.get("tge") is True:
            event = "TGE_SOON"
        else:
            event = "ACTIVE"

    # ---- category ----
    category = data.get("category", "TESTNET")
    if category not in {"TESTNET", "DEPIN"}:
        category = "TESTNET"

    # ---- id & timestamps ----
    project_id = data.get("id")
    if not project_id:
        project_id = generate_uid()

    now = datetime.utcnow()
    created_at = parse_datetime(data.get("created_at")) or now
    updated_at = parse_datetime(data.get("updated_at")) or now

    return {
        "id": str(project_id),
        "category": category,
        "name": str(data.get("name", "")),
        "logo": str(data.get("logo", "")),
        "links": links,
        "tasks": tasks,
        "favorite": bool(data.get("favorite", False)),
        "event": event,
        "analysis": analysis,
        "created_at": created_at,
        "updated_at": updated_at
    }
