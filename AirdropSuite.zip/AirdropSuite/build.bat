@echo off
REM ============================================================
REM  AirdropSuite — Build EXE (PyInstaller, ONEDIR, Windowed)
REM ============================================================
REM  Yeu cau:
REM    - Da cai Python 3.10+ va chay duoc "python" tu Command Prompt
REM    - File nay phai nam o THU MUC GOC project (cung cap voi
REM      launcher.py, backend\, app1\, app2\, assets\)
REM
REM  Chay:
REM    build.bat
REM
REM  Ket qua:
REM    dist\AirdropSuite\AirdropSuite.exe   (+ toan bo file phu tro)
REM ============================================================

setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ============================================
echo   AirdropSuite - Build EXE (ONEDIR)
echo ============================================
echo.

REM ------------------------------------------------------------
REM [1/6] Kiem tra Python
REM ------------------------------------------------------------
where python >nul 2>nul
if errorlevel 1 (
    echo [LOI] Khong tim thay "python" trong PATH.
    echo        Hay cai Python 3.10+ tu https://www.python.org/downloads/
    echo        va nho tick "Add Python to PATH" khi cai dat.
    pause
    exit /b 1
)

echo [1/6] Da tim thay Python:
python --version
echo.

REM ------------------------------------------------------------
REM [2/6] Cai dependencies (requirements.txt + pyinstaller)
REM ------------------------------------------------------------
echo [2/6] Cai dat dependencies (co the mat vai phut lan dau)...
python -m pip install --upgrade pip >nul
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo [LOI] Cai requirements.txt that bai. Kiem tra ket noi mang / requirements.txt.
    pause
    exit /b 1
)
python -m pip install pyinstaller
if errorlevel 1 (
    echo [LOI] Cai PyInstaller that bai.
    pause
    exit /b 1
)
echo.

REM ------------------------------------------------------------
REM [3/6] Don dep ban build cu + tach du lieu dev (database.db)
REM       ra khoi ban build (khong ship du lieu test cua dev cho
REM       nguoi dung cuoi — moi may se tu tao database.db rong
REM       trong %%LOCALAPPDATA%%\AirdropSuite khi chay lan dau).
REM ------------------------------------------------------------
echo [3/6] Don dep va tach du lieu dev...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

set "DEV_DB=backend\database.db"
set "DEV_DB_BAK=backend\database.db.devbak"
if exist "%DEV_DB%" (
    echo   - Tam thoi tach backend\database.db ^(du lieu dev^) ra khoi ban build...
    if exist "%DEV_DB_BAK%" del /q "%DEV_DB_BAK%"
    ren "%DEV_DB%" "database.db.devbak"
)
echo.

REM ------------------------------------------------------------
REM [4/6] Build bang PyInstaller — ONEDIR, WINDOWED (khong console),
REM       kem icon + copy toan bo backend/app1/app2/assets vao dist.
REM ------------------------------------------------------------
echo [4/6] Dang dong goi ONEDIR bang PyInstaller (co the mat vai phut)...
pyinstaller launcher.py ^
  --name "AirdropSuite" ^
  --noconfirm ^
  --clean ^
  --windowed ^
  --onedir ^
  --icon=assets\app.ico ^
  --add-data "backend;backend" ^
  --add-data "app1;app1" ^
  --add-data "app2;app2" ^
  --add-data "assets;assets" ^
  --collect-all fastapi ^
  --collect-all uvicorn ^
  --collect-all starlette ^
  --collect-all pydantic ^
  --collect-all pydantic_core ^
  --collect-all jinja2 ^
  --collect-all anyio ^
  --collect-all sniffio ^
  --hidden-import multipart ^
  --hidden-import email.mime.multipart ^
  --hidden-import sqlalchemy.sql.default_comparator

set BUILD_ERR=%errorlevel%

REM ------------------------------------------------------------
REM [5/6] Khoi phuc database.db dev (du build thanh cong hay that bai,
REM       KHONG duoc de mat file goc cua developer).
REM ------------------------------------------------------------
echo.
echo [5/6] Khoi phuc backend\database.db (du lieu dev)...
if exist "%DEV_DB_BAK%" (
    if exist "%DEV_DB%" del /q "%DEV_DB%"
    ren "%DEV_DB_BAK%" "database.db"
)

if not "%BUILD_ERR%"=="0" (
    echo.
    echo [LOI] PyInstaller bao loi ^(exit code %BUILD_ERR%^). Xem log phia tren.
    pause
    exit /b 1
)

if not exist "dist\AirdropSuite\AirdropSuite.exe" (
    echo.
    echo [LOI] Build "thanh cong" nhung khong thay AirdropSuite.exe trong dist\AirdropSuite\
    pause
    exit /b 1
)

REM ------------------------------------------------------------
REM [6/6] Hoan tat
REM ------------------------------------------------------------
echo.
echo ============================================
echo   BUILD HOAN TAT!
echo ============================================
echo   Thu muc ket qua : dist\AirdropSuite\
echo   Chay thu        : dist\AirdropSuite\AirdropSuite.exe
echo.
echo   Luu y: mang toan bo thu muc "dist\AirdropSuite" khi copy
echo   sang may khac (ONEDIR can day du cac file/DLL ben trong,
echo   khong chi rieng file .exe).
echo ============================================
pause
