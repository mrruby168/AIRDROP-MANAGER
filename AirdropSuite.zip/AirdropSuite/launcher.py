"""
launcher.py
-----------
Airdrop Suite Launcher.

Chạy:
    python launcher.py

Launcher sẽ:
  1) Khởi động FastAPI Backend (Uvicorn) trong background thread.
  2) Kiểm tra Backend đã sẵn sàng (health check /api/health).
  3) Mở cửa sổ Launcher (Tkinter) với 2 nút: APP 1 / APP 2.
  4) Khi đóng cửa sổ Launcher -> tự động shutdown Backend hoàn toàn,
     giải phóng process, không để lại tiến trình nền (zombie process).

Không cần biết Python / FastAPI. Chỉ cần:
    pip install -r requirements.txt
    python launcher.py
"""

from __future__ import annotations

import os
import sys

# ------------------------------------------------------------------ #
# FIX QUAN TRỌNG cho bản build .exe (--windowed, không console):
# Khi không có console, Windows/PyInstaller set sys.stdout/stderr/stdin
# = None (KHÔNG PHẢI file giả — thực sự là None). Rất nhiều thứ không
# kiểm tra None trước khi dùng và sẽ crash ngay khi khởi động:
#   - print(...) bất kỳ trong launcher.py/backend
#   - uvicorn.Config(...) -> configure_logging() -> Formatter.__init__
#     gọi sys.stdout.isatty() -> AttributeError: 'NoneType' object has
#     no attribute 'isatty' (chính là lỗi ĐÓNG EXE đã gặp)
# Phải patch NGAY dòng đầu tiên, trước mọi import/print/logging khác.
# ------------------------------------------------------------------ #
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w", encoding="utf-8")
if sys.stdin is None:
    sys.stdin = open(os.devnull, "r", encoding="utf-8")

import time
import json
import math
import queue
import shutil
import threading
import webbrowser
import subprocess
import urllib.request
import urllib.error

HOST = "127.0.0.1"
PORT = 8000
BASE_URL = f"http://{HOST}:{PORT}"

def _get_project_root() -> str:
    """Xác định thư mục gốc chứa backend/ app1/ app2/, tương thích cả khi
    chạy bằng `python launcher.py` lẫn khi đã đóng gói .exe (PyInstaller
    ONEDIR). Không hardcode ổ đĩa / đường dẫn tuyệt đối."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        # Đã đóng gói: dữ liệu add-data (backend/, app1/, app2/) nằm
        # trong _MEIPASS (với onedir, đây là thư mục con _internal cạnh .exe).
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))


PROJECT_ROOT = _get_project_root()
BACKEND_DIR = os.path.join(PROJECT_ROOT, "backend")


def _fail(msg: str):
    """Báo lỗi khởi động nghiêm trọng. Ưu tiên hiện messagebox (vì bản
    .exe --windowed không có console nào để người dùng đọc print()/input());
    fallback về console cho môi trường dev (python launcher.py)."""
    print(f"[Launcher] LỖI: {msg}")
    shown = False
    try:
        import tkinter
        from tkinter import messagebox
        _root = tkinter.Tk()
        _root.withdraw()
        messagebox.showerror("Airdrop Suite — Lỗi khởi động", msg)
        _root.destroy()
        shown = True
    except Exception:
        shown = False
    if not shown:
        try:
            input("Nhấn Enter để thoát...")
        except Exception:
            pass
    sys.exit(1)


if not os.path.isdir(BACKEND_DIR):
    _fail(f"Không tìm thấy thư mục backend/ tại: {BACKEND_DIR}")

# ------------------------------------------------------------------ #
# backend/main.py dùng bare import ("from config import ...") nên
# thư mục backend/ (KHÔNG phải project root) phải được thêm vào sys.path
# trước khi import. Nhờ vậy launcher.py có thể đặt ở bất kỳ đâu và
# vẫn chạy đúng, không hardcode đường dẫn tuyệt đối.
# ------------------------------------------------------------------ #
sys.path.insert(0, BACKEND_DIR)

try:
    import uvicorn
except ImportError:
    _fail("Thiếu thư viện. Hãy chạy: pip install -r requirements.txt")

try:
    import main as backend_main  # backend/main.py
except Exception as e:
    _fail(f"Không thể khởi tạo Backend (import lỗi): {e}")

app = backend_main.app


class ServerThread(threading.Thread):
    """Chạy Uvicorn server trong thread riêng — có thể shutdown sạch,
    không để lại process nền khi Launcher đóng."""

    def __init__(self, fastapi_app, host: str, port: int):
        super().__init__(daemon=True)
        # log_config=None: bỏ qua bước uvicorn tự dictConfig() logging
        # (formatter mặc định của uvicorn gọi sys.stdout.isatty() để tô
        # màu log — không cần thiết và có thể gây lỗi trong bản .exe
        # --windowed không có console). stdout/stderr đã được patch an
        # toàn ở đầu file phòng trường hợp code khác vẫn in ra console.
        config = uvicorn.Config(
            fastapi_app, host=host, port=port,
            log_level="warning", log_config=None,
        )
        self.server = uvicorn.Server(config)
        self.error = None

    def run(self):
        try:
            self.server.run()
        except Exception as e:  # ví dụ: port đã bị chiếm
            self.error = e

    def stop(self):
        self.server.should_exit = True


def wait_for_server(server_thread: "ServerThread", timeout: float = 15.0) -> bool:
    """Poll /api/health cho tới khi Backend sẵn sàng hoặc hết timeout."""
    deadline = time.time() + timeout
    url = f"{BASE_URL}/api/health"
    while time.time() < deadline:
        if not server_thread.is_alive() and server_thread.error:
            return False
        try:
            with urllib.request.urlopen(url, timeout=1) as resp:
                if resp.status == 200:
                    return True
        except (urllib.error.URLError, ConnectionError, OSError):
            pass
        time.sleep(0.3)
    return False


def fetch_json(url: str, timeout: float = 3.0):
    """Gọi 1 API GET và trả về JSON (dict) hoặc None nếu lỗi. Chỉ dùng để hiển thị UI."""
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


def _find_app_mode_browser() -> str | None:
    """Tìm trình duyệt hỗ trợ chế độ '--app' (cửa sổ riêng, không thanh
    địa chỉ) theo thứ tự ưu tiên Chrome -> Edge -> Brave. Trả về đường dẫn
    executable nếu tìm thấy, None nếu không có (sẽ fallback sang
    webbrowser.open() ở nơi gọi)."""
    candidates: list[str] = []

    if sys.platform.startswith("win"):
        program_files = [
            os.environ.get("PROGRAMFILES", r"C:\Program Files"),
            os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"),
            os.environ.get("LOCALAPPDATA", ""),
        ]
        rel_paths = [
            r"Google\Chrome\Application\chrome.exe",
            r"Microsoft\Edge\Application\msedge.exe",
            r"BraveSoftware\Brave-Browser\Application\brave.exe",
        ]
        for base in program_files:
            if not base:
                continue
            for rel in rel_paths:
                p = os.path.join(base, rel)
                if os.path.isfile(p):
                    candidates.append(p)
        # Cũng thử tìm trong PATH
        for exe in ("chrome.exe", "msedge.exe", "brave.exe"):
            found = shutil.which(exe)
            if found:
                candidates.append(found)
    else:
        for exe in ("google-chrome", "chromium-browser", "microsoft-edge", "brave-browser"):
            found = shutil.which(exe)
            if found:
                candidates.append(found)

    return candidates[0] if candidates else None


def open_app_window(url: str, profile_tag: str = "default"):
    """Mở `url` trong một cửa sổ 'app mode' MAXIMIZE (yêu cầu #5: Full màn
    hình desktop, min size 1280x800). Ưu tiên Chrome/Edge/Brave với cờ
    --app + --start-maximized; nếu máy không có trình duyệt nào phù hợp,
    fallback về webbrowser.open() (mở tab trình duyệt mặc định) để app
    KHÔNG BAO GIỜ bị crash chỉ vì thiếu Chrome/Edge."""
    browser_path = _find_app_mode_browser()
    if browser_path:
        try:
            # user-data-dir riêng cho từng "app" (app1/app2/dashboard) để tránh
            # xung đột với profile Chrome/Edge chính của người dùng và tránh
            # việc mở lại cửa sổ có sẵn thay vì cửa sổ --app mới.
            profile_dir = os.path.join(_get_data_dir(), "browser-profile", profile_tag)
            os.makedirs(profile_dir, exist_ok=True)
            subprocess.Popen(
                [
                    browser_path,
                    f"--app={url}",
                    "--start-maximized",
                    "--window-size=1280,800",
                    f"--user-data-dir={profile_dir}",
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return
        except Exception as e:
            print(f"[Launcher] Không mở được cửa sổ app-mode ({e}), dùng trình duyệt mặc định.")

    # Fallback: trình duyệt mặc định của hệ điều hành (mở tab bình thường).
    webbrowser.open(url)


def _get_data_dir() -> str:
    """Thư mục ghi được, tách biệt khỏi bundle .exe (yêu cầu #7/#8).
    Dev mode: cạnh launcher.py. Frozen (.exe): %LOCALAPPDATA%/AirdropSuite
    (Windows) hoặc thư mục home (các OS khác) — không hardcode ổ đĩa,
    tự tạo nếu chưa tồn tại, không bao giờ throw ra ngoài."""
    try:
        if getattr(sys, "frozen", False):
            base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
            data_dir = os.path.join(base, "AirdropSuite")
        else:
            data_dir = PROJECT_ROOT
        os.makedirs(data_dir, exist_ok=True)
        return data_dir
    except Exception:
        fallback = os.path.join(os.path.expanduser("~"), "AirdropSuite")
        os.makedirs(fallback, exist_ok=True)
        return fallback



def show_launcher_window(backend_ready: bool):
    """Cửa sổ Launcher chính — Control Center hiện đại, dark theme.
    Trả về khi người dùng đóng cửa sổ (Backend sẽ được tắt ở main())."""
    import tkinter as tk
    from tkinter import messagebox

    # ---------- Design tokens (đồng bộ với App1/App2) ----------
    BG = "#0F172A"
    CARD = "#111827"
    CARD_BORDER = "#273449"
    TXT = "#f1f5f9"
    TXT2 = "#94a3b8"
    TXT3 = "#64748b"
    GREEN = "#22c55e"
    GREEN_DARK = "#16a34a"
    ORANGE = "#f97316"
    ORANGE_DARK = "#ea580c"
    BLUE = "#3b82f6"
    BLUE_DARK = "#2563eb"
    RED = "#ef4444"
    FONT = "Segoe UI"

    DATA_DIR = _get_data_dir()
    DB_PATH = os.path.join(DATA_DIR, "database.db")

    root = tk.Tk()
    root.title("Airdrop Suite — Control Center")
    root.geometry("980x700")
    root.minsize(860, 640)
    root.configure(bg=BG)

    # ------------------------------------------------------------ #
    # Small vector icon helper — vẽ icon bằng Canvas (không dùng emoji),
    # đồng bộ phong cách stroke-line cho cả 3 Action Card.
    # ------------------------------------------------------------ #
    def draw_icon(canvas, kind, cx, cy, s, color):
        if kind == "checklist":
            # Clipboard icon — Fluent style, rounded rect body + clip + 3 lines
            w, h = s * 0.50, s * 0.60
            x0, y0 = cx - w / 2, cy - h / 2 + s * 0.04
            r = s * 0.04
            # Main body rounded rectangle (4 arcs + 4 lines)
            canvas.create_arc(x0, y0, x0 + r * 2, y0 + r * 2, start=180, extent=90, outline=color, width=2, style="arc")
            canvas.create_arc(x0 + w - r * 2, y0, x0 + w, y0 + r * 2, start=270, extent=90, outline=color, width=2, style="arc")
            canvas.create_arc(x0, y0 + h - r * 2, x0 + r * 2, y0 + h, start=90, extent=90, outline=color, width=2, style="arc")
            canvas.create_arc(x0 + w - r * 2, y0 + h - r * 2, x0 + w, y0 + h, start=0, extent=90, outline=color, width=2, style="arc")
            canvas.create_line(x0 + r, y0, x0 + w - r, y0, fill=color, width=2)
            canvas.create_line(x0 + r, y0 + h, x0 + w - r, y0 + h, fill=color, width=2)
            canvas.create_line(x0, y0 + r, x0, y0 + h - r, fill=color, width=2)
            canvas.create_line(x0 + w, y0 + r, x0 + w, y0 + h - r, fill=color, width=2)
            # Top clip (rounded rectangle, centered on top edge)
            clip_w, clip_h = w * 0.34, s * 0.10
            clip_x0, clip_y0 = cx - clip_w / 2, y0 - clip_h * 0.6
            clip_r = s * 0.02
            canvas.create_arc(clip_x0, clip_y0, clip_x0 + clip_r * 2, clip_y0 + clip_r * 2, start=180, extent=90, outline=color, width=2, style="arc")
            canvas.create_arc(clip_x0 + clip_w - clip_r * 2, clip_y0, clip_x0 + clip_w, clip_y0 + clip_r * 2, start=270, extent=90, outline=color, width=2, style="arc")
            canvas.create_arc(clip_x0, clip_y0 + clip_h - clip_r * 2, clip_x0 + clip_r * 2, clip_y0 + clip_h, start=90, extent=90, outline=color, width=2, style="arc")
            canvas.create_arc(clip_x0 + clip_w - clip_r * 2, clip_y0 + clip_h - clip_r * 2, clip_x0 + clip_w, clip_y0 + clip_h, start=0, extent=90, outline=color, width=2, style="arc")
            canvas.create_line(clip_x0 + clip_r, clip_y0, clip_x0 + clip_w - clip_r, clip_y0, fill=color, width=2)
            canvas.create_line(clip_x0 + clip_r, clip_y0 + clip_h, clip_x0 + clip_w - clip_r, clip_y0 + clip_h, fill=color, width=2)
            canvas.create_line(clip_x0, clip_y0 + clip_r, clip_x0, clip_y0 + clip_h - clip_r, fill=color, width=2)
            canvas.create_line(clip_x0 + clip_w, clip_y0 + clip_r, clip_x0 + clip_w, clip_y0 + clip_h - clip_r, fill=color, width=2)
            # 3 horizontal lines inside
            for i in range(3):
                ly = y0 + h * 0.30 + i * h * 0.20
                canvas.create_line(x0 + w * 0.18, ly, x0 + w * 0.82, ly, fill=color, width=2)
        elif kind == "chart":
            base = cy + s * 0.26
            for dx, bh in ((-0.22, 0.22), (0.0, 0.40), (0.22, 0.58)):
                bx = cx + dx * s
                canvas.create_rectangle(bx - s * 0.09, base - bh * s, bx + s * 0.09, base,
                                         outline=color, fill=color)
        elif kind == "gear":
            r = s * 0.26
            for i in range(8):
                ang = math.radians(i * 45)
                x1, y1 = cx + math.cos(ang) * r * 1.2, cy + math.sin(ang) * r * 1.2
                x2, y2 = cx + math.cos(ang) * r * 1.55, cy + math.sin(ang) * r * 1.55
                canvas.create_line(x1, y1, x2, y2, fill=color, width=3)
            canvas.create_oval(cx - r, cy - r, cx + r, cy + r, outline=color, width=2)
            r2 = r * 0.42
            canvas.create_oval(cx - r2, cy - r2, cx + r2, cy + r2, outline=color, width=2)

        elif kind == "cloud":
            # Backend / Server icon — Rounded square with horizontal divider
            w = s * 0.50
            h = s * 0.50
            x1 = cx - w / 2
            y1 = cy - h / 2
            x2 = cx + w / 2
            y2 = cy + h / 2
            r = s * 0.04
            # 4 corner arcs
            canvas.create_arc(x1, y1, x1 + 2*r, y1 + 2*r, start=90, extent=90, outline=color, width=2, style="arc")
            canvas.create_arc(x2 - 2*r, y1, x2, y1 + 2*r, start=0, extent=90, outline=color, width=2, style="arc")
            canvas.create_arc(x1, y2 - 2*r, x1 + 2*r, y2, start=180, extent=90, outline=color, width=2, style="arc")
            canvas.create_arc(x2 - 2*r, y2 - 2*r, x2, y2, start=270, extent=90, outline=color, width=2, style="arc")
            # 4 edge lines
            canvas.create_line(x1 + r, y1, x2 - r, y1, fill=color, width=2)
            canvas.create_line(x1 + r, y2, x2 - r, y2, fill=color, width=2)
            canvas.create_line(x1, y1 + r, x1, y2 - r, fill=color, width=2)
            canvas.create_line(x2, y1 + r, x2, y2 - r, fill=color, width=2)
            # Horizontal divider in the middle
            canvas.create_line(x1, cy, x2, cy, fill=color, width=2)
    def icon_badge(parent, kind, color_bg, color_fg, size=72):
        cv = tk.Canvas(parent, width=size, height=size, bg=CARD, highlightthickness=0)
        pad = 2
        cv.create_oval(pad, pad, size - pad, size - pad, fill=color_bg, outline="")
        draw_icon(cv, kind, size / 2, size / 2, size, color_fg)
        return cv

    def rounded_note(parent, text, **kw):
        return tk.Label(parent, text=text, bg=CARD, fg=TXT2, font=(FONT, 10), **kw)

    # ------------------------------------------------------------ #
    # HEADER
    # ------------------------------------------------------------ #
    header = tk.Frame(root, bg=BG)
    header.pack(fill="x", padx=28, pady=(24, 16))

    brand_left = tk.Frame(header, bg=BG)
    brand_left.pack(side="left")

    logo_cv = tk.Canvas(brand_left, width=42, height=42, bg=BG, highlightthickness=0)
    logo_cv.create_rectangle(2, 2, 40, 40, fill=GREEN_DARK, outline="")
    logo_cv.create_text(21, 22, text="A", fill="white", font=(FONT, 18, "bold"))
    logo_cv.pack(side="left", padx=(0, 12))

    title_box = tk.Frame(brand_left, bg=BG)
    title_box.pack(side="left")
    tk.Label(title_box, text="AIRDROP SUITE", font=(FONT, 18, "bold"),
             fg=TXT, bg=BG).pack(anchor="w")
    tk.Label(title_box, text="All-in-one Airdrop Management System",
             font=(FONT, 10), fg=TXT2, bg=BG).pack(anchor="w")

    # Backend status pill (top-right)
    status_pill = tk.Frame(header, bg=CARD, highlightbackground="#2b3b57",
                            highlightthickness=2)
    status_pill.pack(side="right")
    status_inner = tk.Frame(status_pill, bg=CARD)
    status_inner.pack(padx=14, pady=8)
    dot_cv = tk.Canvas(status_inner, width=12, height=12, bg=CARD, highlightthickness=0)
    dot_cv.pack(side="left", padx=(0, 8))
    dot_id = dot_cv.create_oval(1, 1, 11, 11, fill=(GREEN if backend_ready else RED), outline="")
    status_text_box = tk.Frame(status_inner, bg=CARD)
    status_text_box.pack(side="left")
    bs_title = tk.Label(status_text_box, text=("Backend Online" if backend_ready else "Backend Offline"),
                         font=(FONT, 12, "bold"), fg=(GREEN if backend_ready else RED), bg=CARD)
    bs_title.pack(anchor="w")
    bs_sub = tk.Label(status_text_box, text=("All systems operational" if backend_ready else "Kiểm tra Console"),
                       font=(FONT, 8), fg=TXT2, bg=CARD)
    bs_sub.pack(anchor="w")

    # ------------------------------------------------------------ #
    # STATUS CARD ROW — Backend / Database / Total / Testnet / DePIN / Storage
    # ------------------------------------------------------------ #
    status_card = tk.Frame(root, bg=CARD, highlightbackground="#2b3b57", highlightthickness=2)
    status_card.pack(fill="x", padx=28, pady=(0, 16))
    status_row = tk.Frame(status_card, bg=CARD)
    status_row.pack(fill="x", padx=18, pady=16)
    for i in range(6):
        status_row.grid_columnconfigure(i, weight=1)

    def stat_cell(col, label, value_text, value_color=TXT):
        cell = tk.Frame(status_row, bg=CARD)
        cell.grid(row=0, column=col, sticky="w", padx=(0 if col == 0 else 14, 0))
        tk.Label(cell, text=label, font=(FONT, 8, "bold"), fg=TXT3, bg=CARD).pack(anchor="w")
        val = tk.Label(cell, text=value_text, font=(FONT, 15, "bold"), fg=value_color, bg=CARD)
        val.pack(anchor="w", pady=(2, 0))
        if col > 0:
            sep = tk.Frame(status_row, bg=CARD_BORDER, width=1)
            sep.grid(row=0, column=col, sticky="nsw")
        return val

    db_exists = os.path.isfile(DB_PATH)
    val_backend = stat_cell(0, "BACKEND", "Online" if backend_ready else "Offline",
                             GREEN if backend_ready else RED)
    val_database = stat_cell(1, "DATABASE", "Connected" if db_exists else "Not Found",
                              GREEN if db_exists else TXT3)
    val_total = stat_cell(2, "TOTAL PROJECTS", "—")
    val_testnet = stat_cell(3, "TESTNET", "—", BLUE)
    val_depin = stat_cell(4, "DEPIN", "—", ORANGE)
    val_storage_label_col = 5
    storage_cell = tk.Frame(status_row, bg=CARD)
    storage_cell.grid(row=0, column=5, sticky="w", padx=(14, 0))
    tk.Label(storage_cell, text="STORAGE PATH", font=(FONT, 8, "bold"), fg=TXT3, bg=CARD).pack(anchor="w")
    storage_display = DATA_DIR if len(DATA_DIR) < 30 else "..." + DATA_DIR[-27:]
    tk.Label(storage_cell, text=storage_display, font=(FONT, 10), fg=TXT2, bg=CARD).pack(anchor="w", pady=(2, 0))
    sep5 = tk.Frame(status_row, bg=CARD_BORDER, width=1)
    sep5.grid(row=0, column=5, sticky="nsw")

    # ------------------------------------------------------------ #
    # ACTION CARDS — App 1 / App 2 / Backend
    # ------------------------------------------------------------ #
    cards_row = tk.Frame(root, bg=BG)
    cards_row.pack(fill="both", expand=True, padx=28, pady=(0, 16))
    for i in range(3):
        cards_row.grid_columnconfigure(i, weight=1, uniform="cards")
    cards_row.grid_rowconfigure(0, weight=1)

    action_buttons = []

    def make_action_card(col, icon_kind, accent, accent_dark, title, subtitle, desc, on_open):
        card = tk.Frame(cards_row, bg=CARD, highlightbackground="#2b3b57", highlightthickness=2)
        card.grid(row=0, column=col, sticky="nsew", padx=(0 if col == 0 else 10, 0))
        inner = tk.Frame(card, bg=CARD)
        inner.pack(fill="both", expand=True, padx=28, pady=28)

        badge = icon_badge(inner, icon_kind, accent, "#ffffff", size=72)
        badge.pack(pady=(4, 14))

        tk.Label(inner, text=title, font=(FONT, 18, "bold"), fg=TXT, bg=CARD).pack()
        tk.Label(inner, text=subtitle, font=(FONT, 12, "bold"), fg=accent, bg=CARD).pack(pady=(2, 10))
        tk.Label(inner, text=desc, font=(FONT, 10), fg=TXT2, bg=CARD,
                 wraplength=200, justify="center").pack(pady=(0, 16))

        btn = tk.Button(
            inner, text="OPEN", command=on_open,
            font=(FONT, 12, "bold"), bg=accent, fg="white",
            activebackground=accent_dark, activeforeground="white",
            bd=0, relief="flat", cursor="hand2", height=3,
            state=("normal" if backend_ready else "disabled")
        )
        btn.pack(side="bottom", fill="x")
        def enter(e):
            card.config(
                highlightbackground=accent,
                highlightthickness=2
            )

        def leave(e):
            card.config(
                highlightbackground=CARD_BORDER,
                highlightthickness=1
            )

        card.bind("<Enter>",enter)
        card.bind("<Leave>",leave)

        action_buttons.append(btn)
        return card

    def open_app1():
        open_app_window(f"{BASE_URL}/app1/", profile_tag="app1")

    def open_app2():
        open_app_window(f"{BASE_URL}/app2/", profile_tag="app2")

    def open_dashboard():
        open_app_window(f"{BASE_URL}/", profile_tag="dashboard")

    make_action_card(0, "checklist", GREEN, GREEN_DARK, "APP 1", "Daily Tasks",
                      "Quản lý và theo dõi các nhiệm vụ airdrop hàng ngày.", open_app1)
    make_action_card(1, "chart", ORANGE,  ORANGE_DARK, "APP 2", "Project Analysis",
                      "Phân tích dự án, roadmap, funding và tin tức chi tiết.", open_app2)
    make_action_card(2, "cloud", BLUE, BLUE_DARK, "BACKEND", "Dashboard",
                      "Quản lý server, database và API endpoints.", open_dashboard)

    # ------------------------------------------------------------ #
    # BOTTOM BAR — Server URL / Version / Settings
    # ------------------------------------------------------------ #
    bottom_card = tk.Frame(root, bg=CARD, highlightbackground="#2b3b57", highlightthickness=2)
    bottom_card.pack(fill="x", padx=28, pady=(0, 24))
    bottom_row = tk.Frame(bottom_card, bg=CARD)
    bottom_row.pack(fill="x", padx=18, pady=12)

    def bottom_item(label, value):
        box = tk.Frame(bottom_row, bg=CARD)
        box.pack(side="left", padx=(0, 28))
        tk.Label(box, text=label, font=(FONT, 8, "bold"), fg=TXT3, bg=CARD).pack(anchor="w")
        tk.Label(box, text=value, font=(FONT, 9, "bold"), fg=TXT, bg=CARD).pack(anchor="w", pady=(2, 0))

    bottom_item("SERVER URL", BASE_URL)
    bottom_item("VERSION", "Airdrop Suite v1.0.0")

    def open_settings():
        win = tk.Toplevel(root)
        win.title("Cài đặt")
        win.configure(bg=CARD)
        win.geometry("380x260")
        win.resizable(False, False)
        win.transient(root)

        box = tk.Frame(win, bg=CARD)
        box.pack(fill="both", expand=True, padx=20, pady=20)
        tk.Label(box, text="Cài đặt Hệ thống", font=(FONT, 13, "bold"), fg=TXT, bg=CARD).pack(anchor="w", pady=(0, 14))

        def row(label, value):
            r = tk.Frame(box, bg=CARD)
            r.pack(fill="x", pady=5)
            tk.Label(r, text=label, font=(FONT, 10), fg=TXT2, bg=CARD).pack(side="left")
            tk.Label(r, text=value, font=(FONT, 9, "bold"), fg=TXT, bg=CARD).pack(side="right")

        row("Server URL", BASE_URL)
        row("Database File", "database.db" if db_exists else "Not Found")
        row("Storage Path", DATA_DIR)
        row("Version", "1.0.0")

        def open_folder():
            try:
                if sys.platform.startswith("win"):
                    os.startfile(DATA_DIR)  # noqa
                elif sys.platform == "darwin":
                    os.system(f'open "{DATA_DIR}"')
                else:
                    os.system(f'xdg-open "{DATA_DIR}"')
            except Exception:
                pass

        tk.Button(box, text="📁 Mở Thư Mục Dữ Liệu", command=open_folder,
                  font=(FONT, 9, "bold"), bg="#1e2b45", fg=TXT, bd=0,
                  relief="flat", cursor="hand2", height=2).pack(fill="x", pady=(16, 6))
        tk.Button(box, text="Đóng", command=win.destroy,
                  font=(FONT, 10), bg=CARD, fg=TXT2, bd=1,
                  relief="solid", cursor="hand2", height=1).pack(fill="x")

    tk.Button(bottom_row, text="⚙ Settings", command=open_settings,
              font=(FONT, 9, "bold"), bg="#1e2b45", fg=TXT,
              activebackground="#28395a", activeforeground=TXT,
              bd=0, relief="flat", cursor="hand2", padx=14, pady=6
              ).pack(side="right")

    # ------------------------------------------------------------ #
    # Footer
    # ------------------------------------------------------------ #
    tk.Label(root, text="Made with ♥ by Airdrop Suite Team",
             font=(FONT, 8), fg=TXT3, bg=BG).pack(side="bottom", pady=(0, 10))

    # ------------------------------------------------------------ #
    # Background stats polling — không block UI thread, không đổi
    # backend startup/shutdown logic (chỉ đọc /api/stats, /api/health).
    # ------------------------------------------------------------ #
    stats_queue = queue.Queue()
    stop_event = threading.Event()

    def stats_fetcher_loop():
        while not stop_event.is_set():
            data = fetch_json(f"{BASE_URL}/api/stats", timeout=3) if backend_ready else None
            healthy = fetch_json(f"{BASE_URL}/api/health", timeout=2) is not None
            stats_queue.put((data, healthy))
            stop_event.wait(10)

    fetcher_thread = threading.Thread(target=stats_fetcher_loop, daemon=True)
    fetcher_thread.start()

    def set_action_buttons_enabled(enabled: bool):
        for b in action_buttons:
            b.config(state=("normal" if enabled else "disabled"))

    def apply_stats(data, healthy):
        dot_cv.itemconfig(dot_id, fill=(GREEN if healthy else RED))
        bs_title.config(text=("Backend Online" if healthy else "Backend Offline"),
                         fg=(GREEN if healthy else RED))
        bs_sub.config(text=("All systems operational" if healthy else "Backend unavailable"))
        val_backend.config(text=("Online" if healthy else "Offline"), fg=(GREEN if healthy else RED))
        set_action_buttons_enabled(healthy)
        if data:
            val_total.config(text=str(data.get("total_projects", "—")))
            val_testnet.config(text=str(data.get("testnet_projects", "—")))
            val_depin.config(text=str(data.get("depin_projects", "—")))

    def poll_queue():
        try:
            while True:
                data, healthy = stats_queue.get_nowait()
                apply_stats(data, healthy)
        except queue.Empty:
            pass
        root.after(500, poll_queue)

    # Nếu backend đã sẵn sàng từ đầu, hiển thị ngay số liệu đầu tiên
    if backend_ready:
        initial = fetch_json(f"{BASE_URL}/api/stats", timeout=3)
        if initial:
            apply_stats(initial, True)

    root.after(500, poll_queue)

    def on_close():
        if messagebox.askokcancel("Đóng Airdrop Suite", "Đóng Launcher sẽ tắt toàn bộ Backend. Tiếp tục?"):
            stop_event.set()
            root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)

    # Cho phép Python xử lý Ctrl+C (SIGINT) dù Tkinter đang mainloop
    def _pump():
        root.after(200, _pump)
    root.after(200, _pump)

    root.mainloop()


def run_console_fallback(backend_ready: bool):
    """Fallback khi máy không có Tkinter — dùng menu console."""
    print()
    print("=========================")
    print(" AIRDROP SUITE (Console)")
    print("=========================")
    if backend_ready:
        print(f" Backend: {BASE_URL}  (Online)")
    else:
        print(" Backend: OFFLINE — kiểm tra log lỗi phía trên")
    print()
    print(" [1] Mở APP 1")
    print(" [2] Mở APP 2")
    print(" [3] Mở Backend Dashboard")
    print(" [0] Thoát & tắt Backend")
    print("=========================")
    while True:
        try:
            choice = input("Chọn: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if choice == "1":
            open_app_window(f"{BASE_URL}/app1/", profile_tag="app1")
        elif choice == "2":
            open_app_window(f"{BASE_URL}/app2/", profile_tag="app2")
        elif choice == "3":
            open_app_window(f"{BASE_URL}/", profile_tag="dashboard")
        elif choice == "0":
            break


def main():
    print("=" * 42)
    print(" AIRDROP SUITE — starting...")
    print("=" * 42)
    print(f"[Launcher] Đang khởi động Backend tại {BASE_URL} ...")

    server_thread = ServerThread(app, HOST, PORT)
    server_thread.start()

    backend_ready = wait_for_server(server_thread)

    if backend_ready:
        print("[Launcher] Backend đã sẵn sàng.")
    elif server_thread.error:
        print(f"[Launcher] Backend khởi động lỗi: {server_thread.error}")
        print(f"[Launcher] Có thể cổng {PORT} đang được sử dụng bởi chương trình khác.")
    else:
        print("[Launcher] Backend không phản hồi kịp thời (timeout).")

    try:
        try:
            import tkinter  # noqa: F401
            show_launcher_window(backend_ready)
        except Exception as e:
            print(f"[Launcher] Không thể mở giao diện đồ họa ({e}). Chuyển sang chế độ Console.")
            run_console_fallback(backend_ready)
    finally:
        # finally đảm bảo Backend LUÔN được tắt sạch (không zombie process),
        # kể cả khi show_launcher_window()/run_console_fallback() gặp lỗi
        # không lường trước.
        print("[Launcher] Đang tắt Backend...")
        server_thread.stop()
        server_thread.join(timeout=5)
        print("[Launcher] Đã tắt Backend hoàn toàn. Tạm biệt! 👋")


if __name__ == "__main__":
    main()
